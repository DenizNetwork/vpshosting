#!/usr/bin/env bash
# =============================================================================
# DenizHosting — create_vps.sh
# Provisions a KVM VM using cloud-init and integrates with Tailscale.
#
# Usage:
#   sudo bash create_vps.sh <VM_NAME> <VPS_ID> <API_TOKEN>
#
# Requirements:
#   - virt-install, libvirt, qemu-kvm
#   - cloud-localds (cloud-image-utils)
#   - curl
#   - Ubuntu 22.04 cloud image at /opt/denizhosting/images/ubuntu-22.04-server-cloudimg-amd64.img
# =============================================================================

set -euo pipefail

# ── Arguments ──────────────────────────────────────────────────────────────
VM_NAME="${1:?Usage: $0 <VM_NAME> <VPS_ID> <TOKEN>}"
VPS_ID="${2:?Missing VPS_ID}"
API_TOKEN="${3:?Missing API_TOKEN}"

# ── Config ─────────────────────────────────────────────────────────────────
PANEL_URL="https://vps.deniznetwork.qzz.io"
RECEIVER_URL="${PANEL_URL}/receiver.php"
IMAGES_DIR="/opt/denizhosting/images"
VMS_DIR="/opt/denizhosting/vms"
BASE_IMAGE="${IMAGES_DIR}/ubuntu-22.04-server-cloudimg-amd64.img"
CLOUD_IMAGE_URL="https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img"
LOG_PREFIX="[DenizHosting | VPS ${VPS_ID}]"

# ── VM Specs ───────────────────────────────────────────────────────────────
VM_CORES=7
VM_RAM_MB=4000
VM_DISK_GB=1000

# ── Paths ──────────────────────────────────────────────────────────────────
VM_DIR="${VMS_DIR}/${VM_NAME}"
DISK_IMG="${VM_DIR}/${VM_NAME}.qcow2"
CLOUD_INIT_ISO="${VM_DIR}/cloud-init.iso"
CLOUD_INIT_USER_DATA="${VM_DIR}/user-data"
CLOUD_INIT_META_DATA="${VM_DIR}/meta-data"

# ── Helper: call receiver API ──────────────────────────────────────────────
api_call() {
    local payload="$1"
    curl -s -X POST "${RECEIVER_URL}" \
         -H "Content-Type: application/json" \
         -d "${payload}" \
         --max-time 15 \
         --retry 3 \
         --retry-delay 5 || echo '{"error":"curl failed"}'
}

log() { echo "${LOG_PREFIX} $*"; }

# ── 1. Update status → provisioning ────────────────────────────────────────
log "Starting provisioning for VM: ${VM_NAME}"
api_call "{\"action\":\"set_status\",\"vps_id\":${VPS_ID},\"token\":\"${API_TOKEN}\",\"status\":\"provisioning\"}"

# ── 2. Prepare directories ─────────────────────────────────────────────────
mkdir -p "${VM_DIR}"

# ── 3. Download base image if missing ─────────────────────────────────────
if [[ ! -f "${BASE_IMAGE}" ]]; then
    log "Downloading Ubuntu 22.04 cloud image..."
    mkdir -p "${IMAGES_DIR}"
    wget -q --show-progress -O "${BASE_IMAGE}" "${CLOUD_IMAGE_URL}"
    log "Download complete: ${BASE_IMAGE}"
fi

# ── 4. Create VM disk (thin-provisioned) ──────────────────────────────────
log "Creating ${VM_DISK_GB}GB qcow2 disk..."
qemu-img create -f qcow2 -F qcow2 -b "${BASE_IMAGE}" "${DISK_IMG}" "${VM_DISK_GB}G"
log "Disk created: ${DISK_IMG}"

# ── 5. Generate SSH key for this VM ────────────────────────────────────────
SSH_KEY_PATH="${VM_DIR}/id_rsa_${VM_NAME}"
if [[ ! -f "${SSH_KEY_PATH}" ]]; then
    ssh-keygen -t rsa -b 4096 -N "" -f "${SSH_KEY_PATH}" -C "denizhosting-${VM_NAME}" -q
fi
SSH_PUBLIC_KEY=$(cat "${SSH_KEY_PATH}.pub")

# ── 6. Generate cloud-init user-data ─────────────────────────────────────
# This user-data installs Tailscale, captures the auth URL, and reports back.
cat > "${CLOUD_INIT_USER_DATA}" << CLOUDINIT
#cloud-config
hostname: ${VM_NAME}
fqdn: ${VM_NAME}.internal

users:
  - name: ubuntu
    sudo: ['ALL=(ALL) NOPASSWD:ALL']
    shell: /bin/bash
    ssh_authorized_keys:
      - ${SSH_PUBLIC_KEY}

package_update: true
package_upgrade: false
packages:
  - curl
  - wget
  - htop
  - net-tools
  - jq

runcmd:
  # Install Tailscale
  - curl -fsSL https://tailscale.com/install.sh | sh

  # Start Tailscale in background, capture auth URL
  - |
    tailscale up --accept-dns=false 2>&1 | grep -oP 'https://login\.tailscale\.com\S+' > /tmp/ts_auth_url.txt &
    TS_PID=\$!

    # Wait up to 60s for the URL to appear
    for i in \$(seq 1 30); do
      sleep 2
      if [ -s /tmp/ts_auth_url.txt ]; then
        break
      fi
    done

    TS_URL=\$(cat /tmp/ts_auth_url.txt 2>/dev/null | head -1 | tr -d '[:space:]')
    if [ -n "\$TS_URL" ]; then
      curl -s -X POST "${RECEIVER_URL}" \
        -H "Content-Type: application/json" \
        -d "{\"action\":\"set_ts_url\",\"vps_id\":${VPS_ID},\"token\":\"${API_TOKEN}\",\"url\":\"\$TS_URL\"}" || true
    fi

  # Wait for Tailscale to be authenticated and get IP
  - |
    for i in \$(seq 1 60); do
      sleep 5
      TS_IP=\$(tailscale ip -4 2>/dev/null | head -1 | tr -d '[:space:]')
      if echo "\$TS_IP" | grep -qP '^\d+\.\d+\.\d+\.\d+\$'; then
        curl -s -X POST "${RECEIVER_URL}" \
          -H "Content-Type: application/json" \
          -d "{\"action\":\"set_ts_ip\",\"vps_id\":${VPS_ID},\"token\":\"${API_TOKEN}\",\"ip\":\"\$TS_IP\"}" || true
        break
      fi
    done

final_message: "DenizHosting VM ${VM_NAME} provisioning complete!"
CLOUDINIT

# ── 7. Generate cloud-init meta-data ──────────────────────────────────────
cat > "${CLOUD_INIT_META_DATA}" << EOF
instance-id: ${VM_NAME}
local-hostname: ${VM_NAME}
EOF

# ── 8. Build cloud-init ISO ───────────────────────────────────────────────
log "Building cloud-init ISO..."
cloud-localds "${CLOUD_INIT_ISO}" "${CLOUD_INIT_USER_DATA}" "${CLOUD_INIT_META_DATA}"
log "Cloud-init ISO created: ${CLOUD_INIT_ISO}"

# ── 9. Create and start the VM ────────────────────────────────────────────
log "Creating VM with virt-install..."
virt-install \
  --name        "${VM_NAME}" \
  --ram         "${VM_RAM_MB}" \
  --vcpus       "${VM_CORES}" \
  --cpu         host \
  --os-variant  ubuntu22.04 \
  --disk        "path=${DISK_IMG},format=qcow2,bus=virtio" \
  --disk        "path=${CLOUD_INIT_ISO},device=cdrom,readonly=on" \
  --network     network=default,model=virtio \
  --graphics    none \
  --console     pty,target_type=serial \
  --import \
  --noautoconsole \
  --autostart

log "VM ${VM_NAME} created successfully!"
log "VM specs: ${VM_CORES} cores | ${VM_RAM_MB}MB RAM | ${VM_DISK_GB}GB disk"
log "Waiting for cloud-init and Tailscale authentication..."
log "The panel will update automatically once Tailscale is connected."

# ── 10. Monitor VM status ─────────────────────────────────────────────────
# Wait up to 10 minutes for Tailscale auth
TIMEOUT=600
ELAPSED=0
while [[ ${ELAPSED} -lt ${TIMEOUT} ]]; do
    sleep 15
    ELAPSED=$((ELAPSED + 15))

    # Check if VM is still running
    VM_STATE=$(virsh domstate "${VM_NAME}" 2>/dev/null || echo "undefined")
    if [[ "${VM_STATE}" != "running" ]]; then
        log "WARNING: VM state is '${VM_STATE}'"
        if [[ "${VM_STATE}" == "undefined" ]]; then
            api_call "{\"action\":\"set_status\",\"vps_id\":${VPS_ID},\"token\":\"${API_TOKEN}\",\"status\":\"error\"}"
            log "ERROR: VM no longer exists!"
            exit 1
        fi
    fi
    log "VM running (${ELAPSED}s elapsed). Waiting for Tailscale..."
done

log "Timeout reached. Check VM logs for issues."
log "You can manually run: sudo virsh console ${VM_NAME}"
