<?php
/**
 * DenizHosting — Receiver API
 *
 * Called by the VM creation script (create_vps.sh) to:
 *   1. Submit the Tailscale auth URL (during installation)
 *   2. Submit the Tailscale IP once connected (marks VM as online)
 *
 * Endpoints (POST JSON):
 *   { "action": "set_ts_url",  "vps_id": 1, "token": "...", "url": "https://login.tailscale.com/..." }
 *   { "action": "set_ts_ip",   "vps_id": 1, "token": "...", "ip": "100.x.x.x" }
 *   { "action": "set_status",  "vps_id": 1, "token": "...", "status": "offline" }
 *
 * Security: Token-based auth (defined in config.php / DB settings).
 */

header('Content-Type: application/json');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

// Parse body
$raw  = file_get_contents('php://input');
$body = json_decode($raw, true);

if (!$body || !is_array($body)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON body']);
    exit;
}

// Validate token
$expectedToken = getSetting('tailscale_receiver_token', RECEIVER_SECRET);
$givenToken    = $body['token'] ?? '';

if (!hash_equals($expectedToken, $givenToken)) {
    http_response_code(403);
    echo json_encode(['error' => 'Invalid token']);
    exit;
}

$action = $body['action'] ?? '';
$vpsId  = (int)($body['vps_id'] ?? 0);

if ($vpsId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid vps_id']);
    exit;
}

// Verify VPS exists
$stmt = $pdo->prepare("SELECT id FROM vps_instances WHERE id = ?");
$stmt->execute([$vpsId]);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['error' => 'VPS not found']);
    exit;
}

switch ($action) {

    // ── 1. Store Tailscale auth URL ──────────────────────────────────────────
    case 'set_ts_url':
        $url = filter_var($body['url'] ?? '', FILTER_VALIDATE_URL);
        if (!$url) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid URL']);
            exit;
        }
        $pdo->prepare("UPDATE vps_instances SET tailscale_auth_url = ?, status = 'installing' WHERE id = ?")
            ->execute([$url, $vpsId]);
        echo json_encode(['success' => true, 'message' => 'Tailscale auth URL saved']);
        break;

    // ── 2. Store Tailscale IP, mark online ───────────────────────────────────
    case 'set_ts_ip':
        $ip = $body['ip'] ?? '';
        // Validate Tailscale IP (100.x.x.x range)
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid IP address']);
            exit;
        }
        $pdo->prepare("UPDATE vps_instances SET tailscale_ip = ?, status = 'online', tailscale_auth_url = NULL WHERE id = ?")
            ->execute([$ip, $vpsId]);
        echo json_encode(['success' => true, 'message' => 'VPS is now online', 'ip' => $ip]);
        break;

    // ── 3. Set arbitrary status ──────────────────────────────────────────────
    case 'set_status':
        $allowed = ['provisioning', 'installing', 'online', 'offline', 'error'];
        $status  = $body['status'] ?? '';
        if (!in_array($status, $allowed)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid status']);
            exit;
        }
        $pdo->prepare("UPDATE vps_instances SET status = ? WHERE id = ?")
            ->execute([$status, $vpsId]);
        echo json_encode(['success' => true, 'status' => $status]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Unknown action']);
        break;
}
