#!/usr/bin/env bash
# =============================================================================
# DenizHosting — Master Installation Script
# =============================================================================
# Installs and configures the full DenizHosting VPS panel stack:
#   • QEMU/KVM + Libvirt
#   • Nginx + PHP 8.1-FPM
#   • MariaDB
#   • Tailscale
#   • All web files, scripts, permissions
#
# Usage: sudo bash install.sh
# Target: Ubuntu 22.04 / Debian 12
# =============================================================================

set -euo pipefail

# ── Colours ────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()     { echo -e "${GREEN}[✓]${NC} $*"; }
info()    { echo -e "${CYAN}[→]${NC} $*"; }
warn()    { echo -e "${YELLOW}[!]${NC} $*"; }
error()   { echo -e "${RED}[✗]${NC} $*"; exit 1; }
section() { echo -e "\n${BOLD}${BLUE}══ $* ══${NC}\n"; }

# ── Root check ─────────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root. Use: sudo bash install.sh"
fi

# ── OS check ──────────────────────────────────────────────────────────────
if ! grep -qiE 'ubuntu|debian' /etc/os-release 2>/dev/null; then
    warn "This script is designed for Ubuntu/Debian. Proceeding anyway..."
fi

clear
echo -e "${BOLD}${BLUE}"
cat << 'BANNER'
 ____             _     _   _           _   _             
|  _ \  ___ _ __ (_)___|  | | ___  ___| |_(_)_ __   __ _ 
| | | |/ _ \ '_ \| |_  /  | |/ _ \/ __| __| | '_ \ / _` |
| |_| |  __/ | | | |/ /   | | (_) \__ \ |_| | | | | (_| |
|____/ \___|_| |_|_/___| |_|\___/|___/\__|_|_| |_|\__, |
                                                    |___/ 
BANNER
echo -e "${NC}"
echo -e "${CYAN}Master Installation Script — VPS Hosting Panel${NC}"
echo -e "${CYAN}Target: vps.deniznetwork.qzz.io${NC}\n"

# ── Configuration ──────────────────────────────────────────────────────────
PANEL_DOMAIN="vps.deniznetwork.qzz.io"
WEB_ROOT="/var/www/denizhosting"
SCRIPTS_DIR="/opt/denizhosting/scripts"
IMAGES_DIR="/opt/denizhosting/images"
VMS_DIR="/opt/denizhosting/vms"
LOG_DIR="/var/log/denizhosting"
OWNER_USERNAME="DenizHost"
OWNER_PASSWORD="Denizmax"
DB_NAME="denizhosting"
DB_USER="denizhost_user"
DB_PASS="$(openssl rand -base64 24 | tr -d '+=/' | head -c 28)"
RECEIVER_TOKEN="$(openssl rand -hex 32)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

section "Step 1: System Update & Dependencies"
info "Updating package lists..."
apt-get update -qq

info "Installing base packages..."
apt-get install -y -qq \
    curl wget git unzip software-properties-common \
    apt-transport-https ca-certificates gnupg lsb-release \
    ufw openssl jq

section "Step 2: QEMU/KVM & Libvirt"
info "Installing virtualisation stack..."
apt-get install -y -qq \
    qemu-kvm libvirt-daemon-system libvirt-clients \
    bridge-utils virtinst virt-manager \
    cloud-image-utils cloud-init

# Enable and start libvirtd
systemctl enable --now libvirtd
log "libvirtd started"

# Add www-data to libvirt group
usermod -aG libvirt www-data 2>/dev/null || true
usermod -aG kvm     www-data 2>/dev/null || true
log "www-data added to libvirt/kvm groups"

section "Step 3: Nginx Web Server"
info "Installing Nginx..."
apt-get install -y -qq nginx

systemctl enable nginx
log "Nginx installed"

section "Step 4: PHP 8.1"
info "Setting up PHP 8.1 repository..."
add-apt-repository -y ppa:ondrej/php 2>/dev/null || \
  (curl -fsSL https://packages.sury.org/php/apt.gpg | gpg --dearmor -o /etc/apt/trusted.gpg.d/sury-php.gpg && \
   echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" > /etc/apt/sources.list.d/sury-php.list && \
   apt-get update -qq)

info "Installing PHP 8.1 and extensions..."
apt-get install -y -qq \
    php8.1 php8.1-fpm php8.1-mysql php8.1-curl php8.1-mbstring \
    php8.1-xml php8.1-zip php8.1-intl php8.1-bcmath php8.1-gd

systemctl enable php8.1-fpm
log "PHP 8.1-FPM installed"

section "Step 5: MariaDB"
info "Installing MariaDB..."
apt-get install -y -qq mariadb-server mariadb-client

systemctl enable --now mariadb
log "MariaDB started"

info "Securing MariaDB and creating database..."

# Create DB, user, schema
HASHED_PASS=$(php8.1 -r "echo password_hash('${OWNER_PASSWORD}', PASSWORD_BCRYPT, ['cost'=>12]);")

mysql -uroot << MYSQL_SCRIPT
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'127.0.0.1';

USE \`${DB_NAME}\`;

CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(80) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    role       ENUM('owner','user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vps_instances (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    user_id           INT NOT NULL,
    vm_name           VARCHAR(100) NOT NULL UNIQUE,
    status            ENUM('provisioning','installing','online','offline','error') DEFAULT 'provisioning',
    tailscale_auth_url TEXT,
    tailscale_ip      VARCHAR(45),
    cores             INT DEFAULT 7,
    ram_mb            INT DEFAULT 4000,
    disk_gb           INT DEFAULT 1000,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_vps_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
    setting_key   VARCHAR(100) PRIMARY KEY,
    setting_value TEXT,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO settings (setting_key, setting_value) VALUES
    ('work_mode',                '0'),
    ('panel_name',               'DenizHosting'),
    ('tailscale_receiver_token', '${RECEIVER_TOKEN}')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

INSERT INTO users (username, password, role) VALUES
    ('${OWNER_USERNAME}', '${HASHED_PASS}', 'owner')
ON DUPLICATE KEY UPDATE password = VALUES(password), role = 'owner';

FLUSH PRIVILEGES;
MYSQL_SCRIPT

log "Database '${DB_NAME}' configured with user '${DB_USER}'"
log "Owner account '${OWNER_USERNAME}' created"

section "Step 6: Tailscale"
info "Installing Tailscale..."
curl -fsSL https://tailscale.com/install.sh | sh || \
  warn "Tailscale install may have failed — install manually if needed"
log "Tailscale installed"

section "Step 7: Directory Structure"
info "Creating directories..."
mkdir -p "${WEB_ROOT}"
mkdir -p "${SCRIPTS_DIR}"
mkdir -p "${IMAGES_DIR}"
mkdir -p "${VMS_DIR}"
mkdir -p "${LOG_DIR}"

section "Step 8: Web Files"
info "Copying web files to ${WEB_ROOT}..."

# ── config.php ─────────────────────────────────────────────────────────────
cat > "${WEB_ROOT}/config.php" << PHPCONFIG
<?php
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', '${DB_NAME}');
define('DB_USER', '${DB_USER}');
define('DB_PASS', '${DB_PASS}');
define('SCRIPTS_PATH', '${SCRIPTS_DIR}');
define('RECEIVER_SECRET', '${RECEIVER_TOKEN}');
define('PANEL_URL', 'https://${PANEL_DOMAIN}');
PHPCONFIG

# Copy remaining PHP files from package
for f in index.php db.php receiver.php; do
    if [[ -f "${SCRIPT_DIR}/web/${f}" ]]; then
        cp "${SCRIPT_DIR}/web/${f}" "${WEB_ROOT}/${f}"
        log "Copied ${f}"
    else
        warn "${f} not found in ${SCRIPT_DIR}/web/ — ensure all files are present"
    fi
done

# ── Inject receiver token into receiver.php ────────────────────────────────
sed -i "s/CHANGE_THIS_SECRET_TOKEN_123/${RECEIVER_TOKEN}/g" "${WEB_ROOT}/receiver.php" 2>/dev/null || true

log "Web files installed at ${WEB_ROOT}"

section "Step 9: Scripts"
info "Installing create_vps.sh..."
if [[ -f "${SCRIPT_DIR}/scripts/create_vps.sh" ]]; then
    cp "${SCRIPT_DIR}/scripts/create_vps.sh" "${SCRIPTS_DIR}/create_vps.sh"
else
    warn "create_vps.sh not found — please place it at ${SCRIPTS_DIR}/create_vps.sh manually"
fi

# Update PANEL_URL and token in script
sed -i "s|https://vps.deniznetwork.qzz.io|https://${PANEL_DOMAIN}|g" "${SCRIPTS_DIR}/create_vps.sh" 2>/dev/null || true

chmod 750 "${SCRIPTS_DIR}/create_vps.sh"
log "create_vps.sh installed"

section "Step 10: Permissions"
info "Setting ownership and permissions..."
chown -R www-data:www-data "${WEB_ROOT}"
chmod -R 755 "${WEB_ROOT}"
chmod 640 "${WEB_ROOT}/config.php"  # Restrict config
chmod 640 "${WEB_ROOT}/db.php"

chown -R www-data:www-data "${VMS_DIR}" "${LOG_DIR}"
chown -R root:libvirt "${SCRIPTS_DIR}" "${IMAGES_DIR}"
chmod -R 770 "${IMAGES_DIR}" "${VMS_DIR}"

# ── sudoers: let www-data run create_vps.sh as root ───────────────────────
info "Configuring sudoers for www-data..."
SUDOERS_LINE="www-data ALL=(ALL) NOPASSWD: /usr/bin/bash ${SCRIPTS_DIR}/create_vps.sh *"
SUDOERS_FILE="/etc/sudoers.d/denizhosting"
echo "${SUDOERS_LINE}" > "${SUDOERS_FILE}"
chmod 440 "${SUDOERS_FILE}"
visudo -cf "${SUDOERS_FILE}" && log "Sudoers configured" || error "Sudoers syntax error!"

section "Step 11: Nginx Configuration"
info "Installing Nginx virtual host..."
if [[ -f "${SCRIPT_DIR}/config/nginx-denizhosting.conf" ]]; then
    cp "${SCRIPT_DIR}/config/nginx-denizhosting.conf" /etc/nginx/sites-available/denizhosting
else
    # Generate inline
    cat > /etc/nginx/sites-available/denizhosting << NGINXCONF
server {
    listen 80;
    server_name ${PANEL_DOMAIN};
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${PANEL_DOMAIN};
    root ${WEB_ROOT};
    index index.php;

    access_log /var/log/nginx/denizhosting_access.log;
    error_log  /var/log/nginx/denizhosting_error.log;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ ^/(config|db)\.php$ {
        deny all;
        return 404;
    }

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ /\. { deny all; }
}
NGINXCONF
fi

# Enable site
ln -sf /etc/nginx/sites-available/denizhosting /etc/nginx/sites-enabled/denizhosting
rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true

nginx -t && systemctl reload nginx
log "Nginx configured for ${PANEL_DOMAIN}"

section "Step 12: SSL Certificate (Let's Encrypt)"
info "Installing Certbot..."
apt-get install -y -qq certbot python3-certbot-nginx || warn "Certbot install failed — install manually"

info "Requesting SSL certificate for ${PANEL_DOMAIN}..."
info "(Make sure DNS for ${PANEL_DOMAIN} points to this server's IP first!)"
read -rp "  → Press ENTER to attempt certificate issuance, or Ctrl+C to skip: "

certbot --nginx -d "${PANEL_DOMAIN}" --non-interactive --agree-tos \
    --register-unsafely-without-email 2>/dev/null || \
    warn "SSL cert failed. Run manually: sudo certbot --nginx -d ${PANEL_DOMAIN}"

systemctl reload nginx 2>/dev/null || true

section "Step 13: Firewall"
info "Configuring UFW firewall..."
ufw --force reset > /dev/null 2>&1
ufw default deny incoming > /dev/null
ufw default allow outgoing > /dev/null
ufw allow 22/tcp comment "SSH"
ufw allow 80/tcp comment "HTTP"
ufw allow 443/tcp comment "HTTPS"
echo "y" | ufw enable > /dev/null 2>&1 || true
log "Firewall configured (SSH, HTTP, HTTPS allowed)"

section "Step 14: Backup ZIP"
info "Creating project backup..."
BACKUP_DIR="/root/denizhosting-backup"
BACKUP_ZIP="/root/denizhosting-backup-$(date +%Y%m%d-%H%M%S).zip"
mkdir -p "${BACKUP_DIR}"

# Copy all project files
cp -r "${WEB_ROOT}" "${BACKUP_DIR}/web"
cp -r "${SCRIPTS_DIR}" "${BACKUP_DIR}/scripts"
cp "${SCRIPT_DIR}/config/nginx-denizhosting.conf" "${BACKUP_DIR}/" 2>/dev/null || true

# Create manifest
cat > "${BACKUP_DIR}/MANIFEST.txt" << EOF
DenizHosting Backup
Generated: $(date)
Domain:    ${PANEL_DOMAIN}
DB Name:   ${DB_NAME}
DB User:   ${DB_USER}
DB Pass:   ${DB_PASS}
Token:     ${RECEIVER_TOKEN}
EOF

apt-get install -y -qq zip > /dev/null
zip -r "${BACKUP_ZIP}" "${BACKUP_DIR}" > /dev/null
log "Backup created: ${BACKUP_ZIP}"

section "Installation Complete!"

echo -e "\n${BOLD}${GREEN}╔══════════════════════════════════════════════════╗"
echo -e "║       DenizHosting Successfully Installed!       ║"
echo -e "╚══════════════════════════════════════════════════╝${NC}\n"

echo -e "${BOLD}📌 Access Details:${NC}"
echo -e "   Panel URL:       ${CYAN}https://${PANEL_DOMAIN}${NC}"
echo -e "   Owner Username:  ${CYAN}${OWNER_USERNAME}${NC}"
echo -e "   Owner Password:  ${CYAN}${OWNER_PASSWORD}${NC}"

echo -e "\n${BOLD}🗄  Database:${NC}"
echo -e "   Name:     ${CYAN}${DB_NAME}${NC}"
echo -e "   User:     ${CYAN}${DB_USER}${NC}"
echo -e "   Password: ${CYAN}${DB_PASS}${NC}"

echo -e "\n${BOLD}🔒 API Token:${NC}"
echo -e "   ${CYAN}${RECEIVER_TOKEN}${NC}"

echo -e "\n${BOLD}📁 Paths:${NC}"
echo -e "   Web Root:  ${WEB_ROOT}"
echo -e "   Scripts:   ${SCRIPTS_DIR}"
echo -e "   VMs:       ${VMS_DIR}"
echo -e "   Images:    ${IMAGES_DIR}"
echo -e "   Logs:      ${LOG_DIR}"
echo -e "   Backup:    ${BACKUP_ZIP}"

echo -e "\n${BOLD}${YELLOW}⚠  Next Steps:${NC}"
echo -e "   1. Point DNS for ${PANEL_DOMAIN} → this server's IP"
echo -e "   2. Run Tailscale auth on the host: ${CYAN}sudo tailscale up${NC}"
echo -e "   3. Ensure KVM virtualisation is supported: ${CYAN}kvm-ok${NC}"
echo -e "   4. Save your credentials from above or from: ${BACKUP_ZIP}"
echo ""
