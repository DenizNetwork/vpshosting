<?php
/**
 * DenizHosting — Configuration
 * Edit these values to match your environment.
 */

// ── Database ────────────────────────────────────────────────────────────────
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'denizhosting');
define('DB_USER', 'denizhost_user');
define('DB_PASS', 'WILL_BE_SET_BY_INSTALLER');

// ── Paths ───────────────────────────────────────────────────────────────────
define('SCRIPTS_PATH', '/opt/denizhosting/scripts');

// ── Security ────────────────────────────────────────────────────────────────
define('RECEIVER_SECRET', 'CHANGE_THIS_SECRET_TOKEN_123'); // Must match DB setting

// ── Domain ──────────────────────────────────────────────────────────────────
define('PANEL_URL', 'https://vps.deniznetwork.qzz.io');
