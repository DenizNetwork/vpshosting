<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

// ── helpers ────────────────────────────────────────────────────────────────
function isOwner(): bool { return ($_SESSION['role'] ?? '') === 'owner'; }
function isLoggedIn(): bool { return isset($_SESSION['user_id']); }
function redirect(string $to): void { header("Location: $to"); exit; }

// ── work-mode gate ─────────────────────────────────────────────────────────
$workMode = (bool)(int)getSetting('work_mode');
if ($workMode && !isOwner() && !isLoggedIn()) {
    // show maintenance page (non-owners who aren't logged in see it immediately)
}

// ── POST actions ───────────────────────────────────────────────────────────
$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        redirect('index.php');
    } else {
        $loginError = 'Invalid credentials. Please try again.';
    }
}

if ($action === 'logout') {
    session_destroy();
    redirect('index.php');
}

if ($action === 'toggle_work_mode' && isOwner()) {
    $current = (int)getSetting('work_mode');
    setSetting('work_mode', (string)(1 - $current));
    redirect('index.php');
}

if ($action === 'create_vps' && isLoggedIn()) {
    $userId = (int)$_SESSION['user_id'];
    // Check limit: 1 VPS per user (adjust as needed)
    $count = $pdo->prepare("SELECT COUNT(*) FROM vps_instances WHERE user_id = ?");
    $count->execute([$userId]);
    if ($count->fetchColumn() < 1) {
        $vmName = 'vps-' . $_SESSION['username'] . '-' . time();
        $pdo->prepare("INSERT INTO vps_instances (user_id, vm_name, status) VALUES (?,?,?)")
            ->execute([$userId, $vmName, 'provisioning']);
        $vpsId = $pdo->lastInsertId();
        // Spawn VM creation in background
        $scriptPath = SCRIPTS_PATH . '/create_vps.sh';
        $logPath    = '/var/log/denizhosting/vps-' . $vpsId . '.log';
        $token      = getSetting('tailscale_receiver_token');
        $cmd = "sudo bash " . escapeshellarg($scriptPath)
             . " " . escapeshellarg($vmName)
             . " " . escapeshellarg((string)$vpsId)
             . " " . escapeshellarg($token)
             . " > " . escapeshellarg($logPath)
             . " 2>&1 &";
        shell_exec($cmd);
    }
    redirect('index.php');
}

if ($action === 'delete_vps' && isLoggedIn()) {
    $vpsId = (int)($_POST['vps_id'] ?? 0);
    $stmt  = $pdo->prepare("SELECT vm_name, user_id FROM vps_instances WHERE id = ?");
    $stmt->execute([$vpsId]);
    $vps = $stmt->fetch();
    if ($vps && ($vps['user_id'] == $_SESSION['user_id'] || isOwner())) {
        // Destroy the VM
        $vmName = escapeshellarg($vps['vm_name']);
        shell_exec("sudo virsh destroy $vmName 2>/dev/null");
        shell_exec("sudo virsh undefine $vmName --remove-all-storage 2>/dev/null");
        $pdo->prepare("DELETE FROM vps_instances WHERE id = ?")->execute([$vpsId]);
    }
    redirect('index.php');
}

// ── fetch data ─────────────────────────────────────────────────────────────
$vpsList = [];
if (isLoggedIn()) {
    if (isOwner()) {
        $stmt = $pdo->query("SELECT v.*, u.username FROM vps_instances v JOIN users u ON v.user_id = u.id ORDER BY v.created_at DESC");
    } else {
        $stmt = $pdo->prepare("SELECT v.*, u.username FROM vps_instances v JOIN users u ON v.user_id = u.id WHERE v.user_id = ? ORDER BY v.created_at DESC");
        $stmt->execute([$_SESSION['user_id']]);
    }
    $vpsList = $stmt->fetchAll();
}

$allUsers = [];
if (isOwner()) {
    $allUsers = $pdo->query("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC")->fetchAll();
}

$workMode = (bool)(int)getSetting('work_mode');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DenizHosting – VPS Panel</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* ── Variables ─────────────────────────────────────── */
:root {
  --bg:        #0a0e1a;
  --bg2:       #0f1628;
  --bg3:       #151e35;
  --accent:    #3b82f6;
  --accent2:   #6366f1;
  --green:     #22c55e;
  --red:       #ef4444;
  --orange:    #f97316;
  --text:      #e2e8f0;
  --text2:     #94a3b8;
  --border:    rgba(255,255,255,0.07);
  --card:      rgba(255,255,255,0.04);
  --radius:    14px;
  --shadow:    0 8px 32px rgba(0,0,0,0.4);
}

* { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'Segoe UI', system-ui, sans-serif;
  background: var(--bg);
  color: var(--text);
  min-height: 100vh;
  background-image:
    radial-gradient(ellipse 80% 50% at 50% -20%, rgba(59,130,246,0.15) 0%, transparent 60%),
    radial-gradient(ellipse 60% 40% at 80% 80%, rgba(99,102,241,0.08) 0%, transparent 50%);
}

a { color: var(--accent); text-decoration: none; }

/* ── Scrollbar ─────────────────────────────────────── */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--bg3); border-radius: 3px; }

/* ── Navbar ────────────────────────────────────────── */
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2rem;
  height: 64px;
  background: rgba(15,22,40,0.9);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border);
  position: sticky; top: 0; z-index: 100;
}
.nav-brand {
  display: flex; align-items: center; gap: 10px;
  font-size: 1.2rem; font-weight: 700;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.nav-brand i { font-size: 1.4rem; -webkit-text-fill-color: var(--accent); }
.nav-actions { display: flex; align-items: center; gap: 12px; }
.nav-user {
  display: flex; align-items: center; gap: 8px;
  font-size: 0.85rem; color: var(--text2);
}
.badge-owner {
  background: linear-gradient(135deg, #f59e0b, #ef4444);
  color: #fff; font-size: 0.65rem; font-weight: 700;
  padding: 2px 7px; border-radius: 99px; letter-spacing: 0.05em;
}

/* ── Buttons ───────────────────────────────────────── */
.btn {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 8px 18px; border-radius: 8px; font-size: 0.85rem;
  font-weight: 600; cursor: pointer; border: none; transition: all .2s;
  text-decoration: none;
}
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover { background: #2563eb; transform: translateY(-1px); box-shadow: 0 4px 16px rgba(59,130,246,0.4); }
.btn-danger  { background: var(--red); color: #fff; }
.btn-danger:hover { background: #dc2626; }
.btn-ghost   { background: var(--card); color: var(--text); border: 1px solid var(--border); }
.btn-ghost:hover { background: var(--bg3); }
.btn-sm { padding: 5px 12px; font-size: 0.78rem; }
.btn-warning { background: var(--orange); color: #fff; }
.btn-success { background: var(--green); color: #fff; }

/* ── Layout ────────────────────────────────────────── */
.container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
.page-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 2rem;
}
.page-title { font-size: 1.6rem; font-weight: 700; }
.page-title span { color: var(--text2); font-size: 1rem; font-weight: 400; margin-left: 8px; }

/* ── Cards ─────────────────────────────────────────── */
.card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 1.5rem;
  box-shadow: var(--shadow);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 1.2rem;
}
.card-title { font-size: 1rem; font-weight: 600; display: flex; align-items: center; gap: 8px; }

/* ── VPS Card ───────────────────────────────────────── */
.vps-grid { display: grid; gap: 1.2rem; }
.vps-card {
  background: var(--bg2);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
  transition: border-color .2s, transform .2s;
}
.vps-card:hover { border-color: rgba(59,130,246,0.3); transform: translateY(-2px); }
.vps-card.online  { border-left: 3px solid var(--green); }
.vps-card.offline { border-left: 3px solid var(--red); }
.vps-card.installing, .vps-card.provisioning { border-left: 3px solid var(--orange); }

.vps-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 1rem 1.2rem;
  border-bottom: 1px solid var(--border);
}
.vps-name { font-weight: 700; font-size: 1rem; }
.vps-owner-tag { font-size: 0.75rem; color: var(--text2); }
.vps-status-row { display: flex; align-items: center; gap: 10px; }

/* Heartbeat */
.heartbeat-icon { font-size: 1.1rem; }
.heartbeat-icon.online  { color: var(--green); animation: heartPulse 1.2s ease-in-out infinite; }
.heartbeat-icon.offline { color: var(--red); }
.heartbeat-icon.installing, .heartbeat-icon.provisioning { color: var(--orange); animation: spin 2s linear infinite; }

@keyframes heartPulse {
  0%,100% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.25); opacity: 0.8; }
}
@keyframes spin {
  from { transform: rotate(0deg); }
  to   { transform: rotate(360deg); }
}

.status-badge {
  font-size: 0.72rem; font-weight: 700; letter-spacing: 0.05em;
  padding: 3px 10px; border-radius: 99px; text-transform: uppercase;
}
.status-badge.online  { background: rgba(34,197,94,.15); color: var(--green); }
.status-badge.offline { background: rgba(239,68,68,.15); color: var(--red); }
.status-badge.installing, .status-badge.provisioning { background: rgba(249,115,22,.15); color: var(--orange); }

.vps-body { padding: 1.2rem; }
.vps-specs {
  display: flex; gap: 1.5rem; margin-bottom: 1.2rem;
  flex-wrap: wrap;
}
.spec-item { display: flex; align-items: center; gap: 6px; font-size: 0.82rem; color: var(--text2); }
.spec-item i { color: var(--accent); width: 14px; }
.spec-item strong { color: var(--text); }

/* Console / Terminal */
.console-wrapper { position: relative; }
.console-box {
  background: #000;
  border: 1px solid rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 1rem;
  font-family: 'Courier New', monospace;
  font-size: 0.78rem;
  color: #a3e635;
  min-height: 90px;
  transition: filter .4s;
}
.console-box.blurred { filter: blur(6px); user-select: none; }
.console-overlay {
  position: absolute; inset: 0;
  display: flex; flex-direction: column;
  align-items: center; justify-content: center;
  gap: 10px; border-radius: 8px;
  background: rgba(10,14,26,0.7);
  backdrop-filter: blur(2px);
}
.console-overlay h4 { font-size: 0.9rem; }
.console-overlay p  { font-size: 0.75rem; color: var(--text2); text-align: center; }
.spinner { width: 28px; height: 28px; border: 3px solid var(--bg3); border-top-color: var(--orange); border-radius: 50%; animation: spin .8s linear infinite; }

.vps-footer {
  display: flex; align-items: center; justify-content: space-between;
  padding: .8rem 1.2rem;
  border-top: 1px solid var(--border);
  background: rgba(0,0,0,0.2);
}
.vps-ip { font-family: monospace; font-size: 0.83rem; color: var(--text2); }
.vps-ip strong { color: var(--text); }

/* ── Tailscale popup ────────────────────────────────── */
.ts-popup {
  background: linear-gradient(135deg, rgba(59,130,246,0.08), rgba(99,102,241,0.08));
  border: 1px solid rgba(99,102,241,0.25);
  border-radius: 10px;
  padding: 1rem;
  margin-top: 1rem;
  display: flex; align-items: flex-start; gap: 12px;
}
.ts-popup i { color: var(--accent2); font-size: 1.3rem; margin-top: 2px; flex-shrink: 0; }
.ts-popup h5 { font-size: 0.9rem; margin-bottom: 4px; }
.ts-popup p  { font-size: 0.78rem; color: var(--text2); margin-bottom: 8px; }
.ts-popup a.btn { font-size: 0.78rem; }

/* ── Login Page ─────────────────────────────────────── */
.login-wrap {
  min-height: 100vh; display: flex; align-items: center; justify-content: center;
  padding: 2rem;
}
.login-card {
  background: var(--bg2); border: 1px solid var(--border);
  border-radius: 20px; padding: 2.5rem; width: 100%; max-width: 400px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.5);
}
.login-logo {
  text-align: center; margin-bottom: 2rem;
}
.login-logo i { font-size: 3rem; color: var(--accent); }
.login-logo h1 { font-size: 1.5rem; font-weight: 800; margin-top: 8px;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.login-logo p { color: var(--text2); font-size: 0.85rem; margin-top: 4px; }
.form-group { margin-bottom: 1rem; }
.form-label { display: block; font-size: 0.82rem; font-weight: 600; margin-bottom: 6px; color: var(--text2); }
.form-control {
  width: 100%; padding: 10px 14px;
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 8px; color: var(--text); font-size: 0.9rem;
  transition: border-color .2s;
  outline: none;
}
.form-control:focus { border-color: var(--accent); }
.form-control::placeholder { color: rgba(148,163,184,0.4); }
.error-msg { background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.3); color: #fca5a5; border-radius: 8px; padding: 10px 14px; font-size: 0.83rem; margin-bottom: 1rem; }

/* ── Maintenance Page ───────────────────────────────── */
.maintenance-wrap {
  min-height: 100vh; display: flex; align-items: center; justify-content: center;
  flex-direction: column; gap: 1.5rem; text-align: center; padding: 2rem;
}
.maintenance-wrap i { font-size: 5rem; color: var(--orange); }
.maintenance-wrap h1 { font-size: 2rem; }
.maintenance-wrap p  { color: var(--text2); max-width: 400px; }

/* ── Owner Panel ────────────────────────────────────── */
.owner-banner {
  background: linear-gradient(90deg, rgba(245,158,11,.12), rgba(239,68,68,.08));
  border: 1px solid rgba(245,158,11,.25);
  border-radius: 10px; padding: 12px 18px;
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 1.5rem;
}
.owner-banner-left { display: flex; align-items: center; gap: 10px; font-size: 0.88rem; }
.owner-banner-left i { color: #f59e0b; }

.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: 0.83rem; }
th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid var(--border); }
th { color: var(--text2); font-weight: 600; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; }
tr:hover td { background: rgba(255,255,255,0.02); }

/* ── Stats row ──────────────────────────────────────── */
.stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px,1fr)); gap: 1rem; margin-bottom: 1.5rem; }
.stat-card {
  background: var(--card); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 1.2rem;
  display: flex; flex-direction: column; gap: 4px;
}
.stat-label { font-size: 0.73rem; color: var(--text2); text-transform: uppercase; letter-spacing: 0.06em; }
.stat-value { font-size: 1.6rem; font-weight: 800; color: var(--text); }
.stat-value.green { color: var(--green); }
.stat-value.orange { color: var(--orange); }
.stat-value.red { color: var(--red); }

/* ── Empty state ─────────────────────────────────────── */
.empty-state { text-align: center; padding: 3rem 2rem; }
.empty-state i { font-size: 3rem; color: var(--text2); opacity: .4; margin-bottom: 1rem; }
.empty-state h3 { font-size: 1.1rem; margin-bottom: .5rem; }
.empty-state p  { font-size: 0.85rem; color: var(--text2); margin-bottom: 1.5rem; }

/* ── Tooltip ─────────────────────────────────────────── */
.tooltip-wrap { position: relative; display: inline-block; }
.tooltip-wrap:hover .tooltip-box { opacity: 1; visibility: visible; }
.tooltip-box {
  position: absolute; bottom: 110%; left: 50%; transform: translateX(-50%);
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 6px; padding: 5px 10px; font-size: 0.73rem;
  white-space: nowrap; opacity: 0; visibility: hidden; transition: opacity .2s;
  pointer-events: none; z-index: 9999;
}

/* ── Responsive ──────────────────────────────────────── */
@media(max-width: 640px) {
  .container { padding: 1rem; }
  .page-header { flex-direction: column; gap: 1rem; align-items: flex-start; }
  .vps-specs { gap: .8rem; }
}
</style>
</head>
<body>

<?php
// ── Maintenance gate ───────────────────────────────────────────────────────
if ($workMode && !isOwner()):
?>
<div class="maintenance-wrap">
  <i class="fa-solid fa-wrench fa-spin"></i>
  <h1>Under Maintenance</h1>
  <p>DenizHosting is currently undergoing scheduled maintenance. Please check back soon.</p>
  <a href="?action=login_page" class="btn btn-ghost"><i class="fa fa-lock"></i> Owner Login</a>
</div>
</body></html>
<?php
    exit;
endif;

// ── Login page ─────────────────────────────────────────────────────────────
if (!isLoggedIn()):
?>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-logo">
      <i class="fa-solid fa-server"></i>
      <h1>DenizHosting</h1>
      <p>VPS Management Panel</p>
    </div>
    <?php if (!empty($loginError)): ?>
      <div class="error-msg"><i class="fa fa-circle-exclamation"></i> <?= htmlspecialchars($loginError) ?></div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="login">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Enter your username" autocomplete="username" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:.5rem;">
        <i class="fa fa-right-to-bracket"></i> Sign In
      </button>
    </form>
    <p style="text-align:center;font-size:0.75rem;color:var(--text2);margin-top:1.5rem;">
      DenizHosting &copy; <?= date('Y') ?> — Powered by KVM/QEMU
    </p>
  </div>
</div>
</body></html>
<?php
    exit;
endif;

// ── Main panel ─────────────────────────────────────────────────────────────
$totalVps    = count($vpsList);
$onlineVps   = count(array_filter($vpsList, fn($v) => $v['status'] === 'online'));
$installingVps = count(array_filter($vpsList, fn($v) => in_array($v['status'], ['installing','provisioning'])));
?>

<!-- Navbar -->
<nav class="navbar">
  <div class="nav-brand">
    <i class="fa-solid fa-server"></i>
    DenizHosting
  </div>
  <div class="nav-actions">
    <div class="nav-user">
      <i class="fa-solid fa-circle-user"></i>
      <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
      <?php if (isOwner()): ?><span class="badge-owner">OWNER</span><?php endif; ?>
    </div>
    <a href="?action=logout" class="btn btn-ghost btn-sm"><i class="fa fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>

<div class="container">

  <?php if (isOwner()): ?>
  <!-- Owner Banner -->
  <div class="owner-banner">
    <div class="owner-banner-left">
      <i class="fa-solid fa-crown"></i>
      <span><strong>Owner Mode Active</strong> — You have full control over all VPS instances and users.</span>
    </div>
    <form method="POST" style="display:inline;">
      <input type="hidden" name="action" value="toggle_work_mode">
      <button type="submit" class="btn btn-sm <?= $workMode ? 'btn-success' : 'btn-warning' ?>">
        <i class="fa fa-<?= $workMode ? 'eye' : 'eye-slash' ?>"></i>
        <?= $workMode ? 'Disable' : 'Enable' ?> Work Mode
      </button>
    </form>
  </div>
  <?php endif; ?>

  <!-- Stats -->
  <div class="stats-row">
    <div class="stat-card">
      <div class="stat-label">Total VPS</div>
      <div class="stat-value"><?= $totalVps ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Online</div>
      <div class="stat-value green"><?= $onlineVps ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Installing</div>
      <div class="stat-value orange"><?= $installingVps ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Offline</div>
      <div class="stat-value red"><?= $totalVps - $onlineVps - $installingVps ?></div>
    </div>
  </div>

  <!-- VPS List -->
  <div class="page-header">
    <div class="page-title">
      My VPS Instances
      <span><?= $totalVps ?> instance<?= $totalVps !== 1 ? 's' : '' ?></span>
    </div>
    <?php
    $userVpsCount = isOwner() ? 0 : count(array_filter($vpsList, fn($v) => $v['user_id'] == $_SESSION['user_id']));
    $canCreate = isOwner() || $userVpsCount < 1;
    if ($canCreate): ?>
    <form method="POST">
      <input type="hidden" name="action" value="create_vps">
      <button type="submit" class="btn btn-primary">
        <i class="fa fa-plus"></i> Create VPS
      </button>
    </form>
    <?php else: ?>
    <div class="tooltip-wrap">
      <button class="btn btn-ghost" disabled><i class="fa fa-plus"></i> Create VPS</button>
      <div class="tooltip-box">You already have an active VPS instance.</div>
    </div>
    <?php endif; ?>
  </div>

  <?php if (empty($vpsList)): ?>
  <div class="card">
    <div class="empty-state">
      <i class="fa-solid fa-server"></i>
      <h3>No VPS Instances Yet</h3>
      <p>Create your first VPS to get started. It will be provisioned automatically with 7 vCores, 4GB RAM, and 1TB storage.</p>
      <?php if ($canCreate): ?>
      <form method="POST">
        <input type="hidden" name="action" value="create_vps">
        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Create My First VPS</button>
      </form>
      <?php endif; ?>
    </div>
  </div>
  <?php else: ?>

  <div class="vps-grid">
    <?php foreach ($vpsList as $vps):
      $st = $vps['status'];
      $isOnline      = $st === 'online';
      $isInstalling  = in_array($st, ['installing','provisioning']);
      $heartClass    = $isOnline ? 'online' : ($isInstalling ? 'installing' : 'offline');
      $heartIcon     = $isOnline ? 'fa-heart' : ($isInstalling ? 'fa-gear' : 'fa-heart');
      $showConsole   = !$isInstalling;
    ?>
    <div class="vps-card <?= $st ?>">
      <div class="vps-header">
        <div>
          <div class="vps-name"><?= htmlspecialchars($vps['vm_name']) ?></div>
          <?php if (isOwner()): ?>
          <div class="vps-owner-tag"><i class="fa fa-user" style="font-size:.7rem;"></i> <?= htmlspecialchars($vps['username']) ?></div>
          <?php endif; ?>
        </div>
        <div class="vps-status-row">
          <i class="fa-solid <?= $heartIcon ?> heartbeat-icon <?= $heartClass ?>"></i>
          <span class="status-badge <?= $st ?>"><?= $st ?></span>
        </div>
      </div>

      <div class="vps-body">
        <!-- Specs -->
        <div class="vps-specs">
          <div class="spec-item"><i class="fa fa-microchip"></i><strong><?= $vps['cores'] ?></strong>&nbsp;vCores</div>
          <div class="spec-item"><i class="fa fa-memory"></i><strong><?= number_format($vps['ram_mb']/1024, 1) ?>GB</strong>&nbsp;RAM</div>
          <div class="spec-item"><i class="fa fa-hard-drive"></i><strong><?= $vps['disk_gb'] ?>GB</strong>&nbsp;SSD</div>
          <div class="spec-item"><i class="fa fa-clock"></i> Created <?= date('M j, Y', strtotime($vps['created_at'])) ?></div>
        </div>

        <!-- Tailscale popup if pending -->
        <?php if (!empty($vps['tailscale_auth_url']) && !$isOnline): ?>
        <div class="ts-popup">
          <i class="fa-brands fa-windows"></i>
          <div>
            <h5>Tailscale Authentication Required</h5>
            <p>Your VM needs Tailscale authentication to come online. Click the button below and approve the device in your Tailscale account.</p>
            <a href="<?= htmlspecialchars($vps['tailscale_auth_url']) ?>" target="_blank" class="btn btn-primary btn-sm">
              <i class="fa fa-link"></i> Authenticate with Tailscale
            </a>
          </div>
        </div>
        <?php endif; ?>

        <!-- Console -->
        <div class="console-wrapper" style="margin-top:1rem;">
          <div class="console-box <?= $isInstalling ? 'blurred' : '' ?>">
            <?php if ($isOnline): ?>
              <span style="color:#6ee7b7;">● Connected via Tailscale</span><br>
              <span style="color:#94a3b8;">$ </span>Welcome to <?= htmlspecialchars($vps['vm_name']) ?><br>
              <span style="color:#94a3b8;">$ </span>Ubuntu 22.04 LTS — KVM Virtual Machine<br>
              <span style="color:#94a3b8;">$ </span>SSH: <strong style="color:#a3e635;">ssh ubuntu@<?= htmlspecialchars($vps['tailscale_ip'] ?? 'N/A') ?></strong>
            <?php elseif ($isInstalling): ?>
              <span style="color:#fb923c;">● Provisioning VM...</span><br>
              Installing cloud image...<br>
              Configuring cloud-init...<br>
              Starting Tailscale...
            <?php else: ?>
              <span style="color:#f87171;">● VM Offline</span><br>
              <span style="color:#94a3b8;">$ </span>Connection unavailable
            <?php endif; ?>
          </div>
          <?php if ($isInstalling): ?>
          <div class="console-overlay">
            <div class="spinner"></div>
            <h4>Installing...</h4>
            <p>Your VM is being provisioned.<br>This may take 2–5 minutes.</p>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="vps-footer">
        <div class="vps-ip">
          <?php if ($isOnline && !empty($vps['tailscale_ip'])): ?>
            <i class="fa fa-network-wired" style="color:var(--green);"></i>
            Tailscale IP: <strong><?= htmlspecialchars($vps['tailscale_ip']) ?></strong>
          <?php elseif ($isInstalling): ?>
            <i class="fa fa-clock" style="color:var(--orange);"></i>
            Awaiting Tailscale connection...
          <?php else: ?>
            <i class="fa fa-times-circle" style="color:var(--red);"></i>
            No active connection
          <?php endif; ?>
        </div>
        <form method="POST" onsubmit="return confirm('Are you sure you want to permanently delete this VPS?');">
          <input type="hidden" name="action" value="delete_vps">
          <input type="hidden" name="vps_id" value="<?= $vps['id'] ?>">
          <button type="submit" class="btn btn-danger btn-sm">
            <i class="fa fa-trash"></i> Delete
          </button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if (isOwner() && !empty($allUsers)): ?>
  <!-- Users Table (Owner Only) -->
  <div class="page-header" style="margin-top:2.5rem;">
    <div class="page-title">All Users <span><?= count($allUsers) ?> accounts</span></div>
  </div>
  <div class="card">
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>ID</th><th>Username</th><th>Role</th><th>Joined</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($allUsers as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['username']) ?></td>
            <td>
              <?php if ($u['role'] === 'owner'): ?>
                <span class="badge-owner">OWNER</span>
              <?php else: ?>
                <span style="color:var(--text2);font-size:.8rem;">user</span>
              <?php endif; ?>
            </td>
            <td style="color:var(--text2);"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

  <p style="text-align:center;font-size:0.73rem;color:var(--text2);margin-top:2.5rem;padding-bottom:1rem;">
    DenizHosting &copy; <?= date('Y') ?> — Powered by QEMU/KVM &amp; Tailscale
  </p>

</div>

<!-- Auto-refresh while VMs installing -->
<?php if ($installingVps > 0): ?>
<script>
  setTimeout(() => location.reload(), 10000); // refresh every 10s
</script>
<?php endif; ?>

</body>
</html>
