# DenizHosting — VPS Panel

A self-hosted KVM/QEMU VPS provisioning panel with Tailscale integration, built on PHP + Nginx + MariaDB.

---

## Quick Start

```bash
# 1. Clone / extract this package to your server
# 2. Run the master installer as root:
sudo bash install.sh
```

The script will handle everything. After it completes, visit your panel URL.

---

## Architecture

```
[User Browser]
      │
      ▼
[Nginx + HTTPS]  ←──  vps.deniznetwork.qzz.io (Cloudflare)
      │
      ▼
[PHP-FPM (index.php)]
      │
      ├── [MariaDB]           ← stores VPS state, users, settings
      │
      └── [shell_exec → sudo]
                │
                ▼
        [create_vps.sh]
                │
                ├── virt-install → QEMU/KVM VM
                │
                └── cloud-init → installs Tailscale in VM
                          │
                          └── VM calls receiver.php with Tailscale URL/IP
```

---

## Credentials

| Item | Value |
|------|-------|
| Owner Username | `DenizHost` |
| Owner Password | `Denizmax` |

> **Change the password** in MariaDB after first login!

---

## File Structure

```
denizhosting/
├── install.sh                    ← Master installer (run this!)
├── README.md
├── web/
│   ├── index.php                 ← Main panel frontend + logic
│   ├── config.php                ← DB & app configuration
│   ├── db.php                    ← PDO database helper
│   └── receiver.php              ← API: receives Tailscale data from VMs
├── scripts/
│   └── create_vps.sh             ← VM provisioning engine
├── config/
│   └── nginx-denizhosting.conf   ← Nginx vhost config
└── sql/
    └── schema.sql                ← Raw SQL schema (applied by installer)
```

---

## VM Specifications (Locked)

| Spec | Value |
|------|-------|
| CPU | 7 vCores (host passthrough) |
| RAM | 4,000 MB |
| Disk | 1 TB (thin-provisioned qcow2) |
| Base OS | Ubuntu 22.04 LTS (cloud image) |
| Network | Tailscale (private mesh) |

---

## Provisioning Flow

1. User clicks **Create VPS** in the panel
2. PHP inserts a new row (`status = provisioning`) and calls `create_vps.sh` via `sudo`
3. `create_vps.sh`:
   - Downloads Ubuntu 22.04 cloud image (if not cached)
   - Creates a 1TB qcow2 disk backed by the base image
   - Generates `cloud-init` user-data with Tailscale install commands
   - Calls `virt-install` to create & boot the VM
4. Inside the VM, cloud-init runs `tailscale up` and captures the auth URL
5. The VM POSTs the auth URL to `receiver.php` → panel shows a popup to the user
6. User clicks the Tailscale link in the popup, authenticates in Tailscale dashboard
7. The VM detects its Tailscale IP and POSTs it to `receiver.php`
8. Panel updates: `status = online`, IP displayed, blur removed ✅

---

## Owner Features

- **Work Mode toggle**: Shows maintenance page to all non-owner users
- **All VPS visible**: Owner sees every user's VPS instances
- **User table**: View all registered accounts

---

## Security

- `config.php` is chmod 640 (not web-accessible)
- `db.php` blocked at Nginx level
- Receiver API uses a 256-bit random token
- `www-data` sudoers entry limited to exactly `create_vps.sh`
- UFW configured: only SSH/80/443

---

## Tailscale Notes

- Each VM connects to the **user's own** Tailscale account (they click the auth link)
- The host server should also run Tailscale if you want host→VM connectivity
- Run `sudo tailscale up` on the host after installation

---

## Manual SSL (if Certbot failed)

```bash
sudo certbot --nginx -d vps.deniznetwork.qzz.io
```

Or use Cloudflare's flexible SSL (proxy mode) for quick setup.

---

## Troubleshooting

**VM creation fails:**
```bash
sudo tail -f /var/log/denizhosting/vps-<ID>.log
```

**Check running VMs:**
```bash
sudo virsh list --all
```

**PHP/Nginx errors:**
```bash
sudo tail -f /var/log/nginx/denizhosting_error.log
sudo tail -f /var/log/php8.1-fpm.log
```

**Verify KVM support:**
```bash
kvm-ok
egrep -c '(vmx|svm)' /proc/cpuinfo  # should be > 0
```
