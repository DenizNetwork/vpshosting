<?php
session_start();
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function isOwner(): bool { return ($_SESSION['role'] ?? '') === 'owner'; }
function redirect(string $to): void { header("Location: $to"); exit; }

$action     = $_POST['action'] ?? $_GET['action'] ?? '';
$loginError = '';

if ($action === 'owner_login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT id, username, password, role FROM users WHERE username = ? AND role = 'owner'");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        redirect('index.php');
    } else {
        $loginError = 'Invalid owner credentials.';
    }
}
if ($action === 'logout' && isOwner()) { session_destroy(); redirect('index.php'); }
if ($action === 'toggle_work_mode' && isOwner()) {
    setSetting('work_mode', (string)(1 - (int)getSetting('work_mode')));
    redirect('index.php');
}
if ($action === 'create_vps' && isOwner()) {
    $vmName = 'vps-' . strtolower(preg_replace('/[^a-z0-9]/', '', $_SESSION['username'])) . '-' . time();
    $pdo->prepare("INSERT INTO vps_instances (user_id, vm_name, status) VALUES (?,?,?)")
        ->execute([$_SESSION['user_id'], $vmName, 'provisioning']);
    $vpsId   = $pdo->lastInsertId();
    $token   = getSetting('tailscale_receiver_token');
    $script  = SCRIPTS_PATH . '/create_vps.sh';
    $logFile = '/var/log/denizhosting/vps-' . $vpsId . '.log';
    shell_exec("sudo bash " . escapeshellarg($script)
        . " " . escapeshellarg($vmName)
        . " " . escapeshellarg((string)$vpsId)
        . " " . escapeshellarg($token)
        . " > " . escapeshellarg($logFile) . " 2>&1 &");
    redirect('index.php');
}
if ($action === 'delete_vps' && isOwner()) {
    $vpsId = (int)($_POST['vps_id'] ?? 0);
    $stmt  = $pdo->prepare("SELECT vm_name FROM vps_instances WHERE id = ?");
    $stmt->execute([$vpsId]);
    $vps = $stmt->fetch();
    if ($vps) {
        $vm = escapeshellarg($vps['vm_name']);
        shell_exec("sudo virsh destroy $vm 2>/dev/null");
        shell_exec("sudo virsh undefine $vm --remove-all-storage 2>/dev/null");
        $pdo->prepare("DELETE FROM vps_instances WHERE id = ?")->execute([$vpsId]);
    }
    redirect('index.php');
}

$workMode      = (bool)(int)getSetting('work_mode');
$vpsList       = [];
$allUsers      = [];
if (isOwner()) {
    $vpsList  = $pdo->query("SELECT v.*, u.username FROM vps_instances v JOIN users u ON v.user_id=u.id ORDER BY v.created_at DESC")->fetchAll();
    $allUsers = $pdo->query("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC")->fetchAll();
}
$totalVps      = count($vpsList);
$onlineVps     = count(array_filter($vpsList, fn($v) => $v['status'] === 'online'));
$installingVps = count(array_filter($vpsList, fn($v) => in_array($v['status'], ['installing','provisioning'])));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DenizHosting — VPS Panel</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root{
  --bg:#080c18;--bg2:#0d1424;--bg3:#121a30;--bg4:#1a2340;
  --accent:#3b82f6;--accent2:#6366f1;--green:#22c55e;--red:#ef4444;
  --orange:#f97316;--yellow:#f59e0b;--text:#e2e8f0;--text2:#94a3b8;
  --border:rgba(255,255,255,0.07);--card:rgba(255,255,255,0.04);
  --radius:14px;--shadow:0 8px 40px rgba(0,0,0,0.5);
}
*{box-sizing:border-box;margin:0;padding:0;}
html,body{min-height:100vh;}
body{font-family:'Segoe UI',system-ui,sans-serif;background:var(--bg);color:var(--text);
  background-image:radial-gradient(ellipse 80% 50% at 50% -20%,rgba(59,130,246,.13) 0%,transparent 60%),
  radial-gradient(ellipse 50% 40% at 80% 90%,rgba(99,102,241,.07) 0%,transparent 50%);}
a{color:var(--accent);text-decoration:none;}
::-webkit-scrollbar{width:5px;}::-webkit-scrollbar-track{background:var(--bg);}
::-webkit-scrollbar-thumb{background:var(--bg4);border-radius:3px;}

/* Navbar */
.navbar{display:flex;align-items:center;justify-content:space-between;padding:0 2rem;height:62px;
  background:rgba(13,20,36,.92);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);
  position:sticky;top:0;z-index:200;}
.nav-brand{display:flex;align-items:center;gap:10px;font-size:1.15rem;font-weight:800;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.nav-brand i{font-size:1.3rem;-webkit-text-fill-color:var(--accent);}
.nav-right{display:flex;align-items:center;gap:10px;}
.owner-chip{display:flex;align-items:center;gap:7px;background:rgba(59,130,246,.12);
  border:1px solid rgba(59,130,246,.25);border-radius:99px;padding:5px 14px;font-size:.8rem;}
.owner-chip i{color:var(--yellow);}
.badge-owner{background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;font-size:.6rem;
  font-weight:800;padding:2px 7px;border-radius:99px;letter-spacing:.06em;}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 18px;border-radius:8px;
  font-size:.84rem;font-weight:600;cursor:pointer;border:none;transition:all .18s;text-decoration:none;}
.btn-primary{background:var(--accent);color:#fff;}
.btn-primary:hover{background:#2563eb;transform:translateY(-1px);box-shadow:0 4px 18px rgba(59,130,246,.4);}
.btn-danger{background:var(--red);color:#fff;}.btn-danger:hover{background:#dc2626;}
.btn-ghost{background:var(--card);color:var(--text);border:1px solid var(--border);}
.btn-ghost:hover{background:var(--bg4);}
.btn-warning{background:var(--orange);color:#fff;}.btn-warning:hover{background:#ea580c;}
.btn-success{background:var(--green);color:#fff;}.btn-success:hover{background:#16a34a;}
.btn-owner{background:linear-gradient(135deg,rgba(245,158,11,.15),rgba(239,68,68,.1));
  color:var(--yellow);border:1px solid rgba(245,158,11,.3);}
.btn-owner:hover{background:linear-gradient(135deg,rgba(245,158,11,.25),rgba(239,68,68,.18));transform:translateY(-1px);}
.btn-sm{padding:5px 12px;font-size:.77rem;}

/* Layout */
.container{max-width:1180px;margin:0 auto;padding:2rem;}
.page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:1.8rem;flex-wrap:wrap;gap:1rem;}
.page-title{font-size:1.5rem;font-weight:700;}
.page-title span{color:var(--text2);font-size:.95rem;font-weight:400;margin-left:8px;}
.card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:1.5rem;box-shadow:var(--shadow);}

/* Stats */
.stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:1rem;margin-bottom:1.5rem;}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:1.2rem;}
.stat-label{font-size:.7rem;color:var(--text2);text-transform:uppercase;letter-spacing:.07em;margin-bottom:4px;}
.stat-value{font-size:1.7rem;font-weight:800;}
.stat-value.green{color:var(--green);}.stat-value.orange{color:var(--orange);}.stat-value.red{color:var(--red);}

/* Owner banner */
.owner-banner{background:linear-gradient(90deg,rgba(245,158,11,.1),rgba(239,68,68,.06));
  border:1px solid rgba(245,158,11,.2);border-radius:10px;padding:12px 18px;
  display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;flex-wrap:wrap;gap:10px;}
.owner-banner-left{display:flex;align-items:center;gap:10px;font-size:.86rem;}
.owner-banner-left i{color:var(--yellow);}

/* VPS Cards */
.vps-grid{display:grid;gap:1.2rem;}
.vps-card{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);
  overflow:hidden;transition:border-color .2s,transform .2s;}
.vps-card:hover{border-color:rgba(59,130,246,.25);transform:translateY(-2px);}
.vps-card.online{border-left:3px solid var(--green);}
.vps-card.offline{border-left:3px solid var(--red);}
.vps-card.installing,.vps-card.provisioning{border-left:3px solid var(--orange);}
.vps-header{display:flex;align-items:center;justify-content:space-between;
  padding:1rem 1.2rem;border-bottom:1px solid var(--border);}
.vps-name{font-weight:700;font-size:.98rem;}
.vps-status-row{display:flex;align-items:center;gap:10px;}
.heartbeat-icon{font-size:1.1rem;}
.heartbeat-icon.online{color:var(--green);animation:heartPulse 1.2s ease-in-out infinite;}
.heartbeat-icon.offline{color:var(--red);}
.heartbeat-icon.installing,.heartbeat-icon.provisioning{color:var(--orange);animation:spin .9s linear infinite;}
@keyframes heartPulse{0%,100%{transform:scale(1);opacity:1;}50%{transform:scale(1.3);opacity:.75;}}
@keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
.status-badge{font-size:.7rem;font-weight:700;letter-spacing:.05em;padding:3px 10px;border-radius:99px;text-transform:uppercase;}
.status-badge.online{background:rgba(34,197,94,.12);color:var(--green);}
.status-badge.offline{background:rgba(239,68,68,.12);color:var(--red);}
.status-badge.installing,.status-badge.provisioning{background:rgba(249,115,22,.12);color:var(--orange);}
.vps-body{padding:1.2rem;}
.vps-specs{display:flex;gap:1.5rem;flex-wrap:wrap;margin-bottom:1.2rem;}
.spec-item{display:flex;align-items:center;gap:6px;font-size:.81rem;color:var(--text2);}
.spec-item i{color:var(--accent);width:14px;}
.spec-item strong{color:var(--text);}
.console-wrapper{position:relative;}
.console-box{background:#000;border:1px solid rgba(255,255,255,.08);border-radius:8px;
  padding:1rem;font-family:'Courier New',monospace;font-size:.77rem;color:#a3e635;
  min-height:90px;transition:filter .4s;}
.console-box.blurred{filter:blur(6px);user-select:none;}
.console-overlay{position:absolute;inset:0;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:10px;border-radius:8px;
  background:rgba(8,12,24,.72);backdrop-filter:blur(2px);}
.console-overlay h4{font-size:.88rem;}
.console-overlay p{font-size:.74rem;color:var(--text2);text-align:center;}
.spinner{width:26px;height:26px;border:3px solid var(--bg4);border-top-color:var(--orange);border-radius:50%;animation:spin .8s linear infinite;}
.vps-footer{display:flex;align-items:center;justify-content:space-between;
  padding:.8rem 1.2rem;border-top:1px solid var(--border);background:rgba(0,0,0,.2);flex-wrap:wrap;gap:8px;}
.vps-ip{font-family:monospace;font-size:.82rem;color:var(--text2);}
.vps-ip strong{color:var(--text);}
.ts-popup{background:linear-gradient(135deg,rgba(59,130,246,.07),rgba(99,102,241,.07));
  border:1px solid rgba(99,102,241,.22);border-radius:10px;padding:1rem;
  margin-top:1rem;display:flex;align-items:flex-start;gap:12px;}
.ts-popup>i{color:var(--accent2);font-size:1.2rem;margin-top:2px;flex-shrink:0;}
.ts-popup h5{font-size:.88rem;margin-bottom:4px;}
.ts-popup p{font-size:.76rem;color:var(--text2);margin-bottom:8px;}

/* Table */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:.82rem;}
th,td{padding:10px 14px;text-align:left;border-bottom:1px solid var(--border);}
th{color:var(--text2);font-weight:600;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;}
tr:hover td{background:rgba(255,255,255,.02);}

/* Empty state */
.empty-state{text-align:center;padding:3rem 2rem;}
.empty-state i{font-size:3rem;color:var(--text2);opacity:.35;margin-bottom:1rem;display:block;}
.empty-state h3{font-size:1.05rem;margin-bottom:.5rem;}
.empty-state p{font-size:.83rem;color:var(--text2);margin-bottom:1.5rem;}

/* Guest hero */
.guest-hero{text-align:center;padding:5rem 2rem 3rem;}
.hero-icon{font-size:4rem;color:var(--accent);margin-bottom:1.5rem;
  animation:heroFloat 3s ease-in-out infinite;display:block;}
@keyframes heroFloat{0%,100%{transform:translateY(0);}50%{transform:translateY(-10px);}}
.guest-hero h1{font-size:2.5rem;font-weight:900;margin-bottom:.75rem;
  background:linear-gradient(135deg,var(--text),var(--accent));
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.guest-hero p{font-size:1.05rem;color:var(--text2);max-width:500px;margin:0 auto 2.5rem;}
.features-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:1rem;max-width:900px;margin:0 auto;}
.feature-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);
  padding:1.4rem;text-align:left;transition:border-color .2s,transform .2s;}
.feature-card:hover{border-color:rgba(59,130,246,.3);transform:translateY(-3px);}
.feature-card i{font-size:1.5rem;color:var(--accent);margin-bottom:.75rem;display:block;}
.feature-card h3{font-size:.95rem;font-weight:700;margin-bottom:.4rem;}
.feature-card p{font-size:.78rem;color:var(--text2);line-height:1.5;}

/* Work mode screen */
.work-mode-wrap{min-height:100vh;display:flex;align-items:center;
  justify-content:center;flex-direction:column;gap:1.5rem;text-align:center;padding:2rem;}
.wm-icon{font-size:5rem;color:var(--orange);animation:spin 6s linear infinite;}
.work-mode-wrap h1{font-size:2rem;font-weight:800;}
.work-mode-wrap p{color:var(--text2);max-width:420px;line-height:1.7;}
.owner-hint{font-size:.82rem;color:var(--text2);margin-top:.5rem;
  display:flex;align-items:center;gap:8px;justify-content:center;flex-wrap:wrap;}

/* Modal */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.78);backdrop-filter:blur(10px);
  z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem;
  opacity:0;visibility:hidden;transition:opacity .25s,visibility .25s;}
.modal-overlay.open{opacity:1;visibility:visible;}
.modal-box{background:var(--bg2);border:1px solid var(--border);border-radius:20px;
  padding:2.2rem;width:100%;max-width:380px;box-shadow:0 24px 60px rgba(0,0,0,.6);
  transform:translateY(20px);transition:transform .25s;position:relative;}
.modal-overlay.open .modal-box{transform:translateY(0);}
.modal-header{text-align:center;margin-bottom:1.8rem;}
.modal-header i{font-size:2.8rem;color:var(--yellow);margin-bottom:.75rem;display:block;}
.modal-header h2{font-size:1.3rem;font-weight:800;}
.modal-header p{font-size:.8rem;color:var(--text2);margin-top:4px;}
.form-group{margin-bottom:.9rem;}
.form-label{display:block;font-size:.8rem;font-weight:600;color:var(--text2);margin-bottom:5px;}
.form-control{width:100%;padding:10px 13px;background:var(--bg3);border:1px solid var(--border);
  border-radius:8px;color:var(--text);font-size:.88rem;transition:border-color .18s;outline:none;}
.form-control:focus{border-color:var(--accent);}
.form-control::placeholder{color:rgba(148,163,184,.35);}
.error-msg{background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);
  color:#fca5a5;border-radius:8px;padding:9px 13px;font-size:.8rem;
  margin-bottom:.9rem;display:flex;align-items:center;gap:7px;}
.modal-close{position:absolute;top:14px;right:16px;background:none;border:none;
  color:var(--text2);font-size:1.2rem;cursor:pointer;padding:4px;transition:color .15s;}
.modal-close:hover{color:var(--text);}

@media(max-width:640px){
  .container{padding:1rem;}
  .guest-hero h1{font-size:1.7rem;}
  .page-header{flex-direction:column;align-items:flex-start;}
  .navbar{padding:0 1rem;}
}
</style>
</head>
<body>

<?php if ($workMode && !isOwner()): ?>
<!-- ══ WORK MODE SCREEN ════════════════════════════════════════════════ -->
<nav class="navbar">
  <div class="nav-brand"><i class="fa-solid fa-server"></i>DenizHosting</div>
  <div class="nav-right">
    <button class="btn btn-owner btn-sm" onclick="openModal()">
      <i class="fa-solid fa-crown"></i> Owner Mode
    </button>
  </div>
</nav>
<div class="work-mode-wrap">
  <i class="fa-solid fa-wrench wm-icon"></i>
  <h1>Under Maintenance</h1>
  <p>DenizHosting is currently undergoing scheduled maintenance. We'll be back shortly — thank you for your patience.</p>
  <div class="owner-hint">
    <i class="fa fa-lock"></i> Are you the owner?
    <button class="btn btn-owner btn-sm" onclick="openModal()">
      <i class="fa-solid fa-crown"></i> Sign in as Owner
    </button>
  </div>
</div>

<?php elseif (!isOwner()): ?>
<!-- ══ GUEST VIEW ═══════════════════════════════════════════════════════ -->
<nav class="navbar">
  <div class="nav-brand"><i class="fa-solid fa-server"></i>DenizHosting</div>
  <div class="nav-right">
    <button class="btn btn-owner btn-sm" onclick="openModal()">
      <i class="fa-solid fa-crown"></i> Owner Mode
    </button>
  </div>
</nav>
<div class="container">
  <div class="guest-hero">
    <i class="fa-solid fa-server hero-icon"></i>
    <h1>DenizHosting</h1>
    <p>High-performance KVM virtual machines provisioned instantly, secured with Tailscale private networking.</p>
    <button class="btn btn-primary" onclick="openModal()" style="font-size:.95rem;padding:11px 28px;">
      <i class="fa-solid fa-crown"></i> Owner Mode
    </button>
  </div>
  <div class="features-grid">
    <div class="feature-card"><i class="fa-solid fa-microchip"></i><h3>7 vCore CPU</h3><p>Dedicated virtual cores with host CPU passthrough for maximum performance.</p></div>
    <div class="feature-card"><i class="fa-solid fa-memory"></i><h3>4 GB RAM</h3><p>4,000 MB of dedicated memory for your workloads and applications.</p></div>
    <div class="feature-card"><i class="fa-solid fa-hard-drive"></i><h3>1 TB Storage</h3><p>Thin-provisioned qcow2 disk backed by fast local NVMe storage.</p></div>
    <div class="feature-card"><i class="fa-brands fa-ubuntu"></i><h3>Ubuntu 22.04</h3><p>Fresh Ubuntu 22.04 LTS cloud image, configured automatically via cloud-init.</p></div>
    <div class="feature-card"><i class="fa-solid fa-shield-halved"></i><h3>Tailscale VPN</h3><p>Private mesh network — no port forwarding needed, fully encrypted access.</p></div>
    <div class="feature-card"><i class="fa-solid fa-bolt"></i><h3>Instant Deploy</h3><p>VM created and online in minutes via automated virt-install and cloud-init.</p></div>
  </div>
  <p style="text-align:center;font-size:.72rem;color:var(--text2);margin-top:3rem;padding-bottom:1rem;">
    DenizHosting &copy; <?= date('Y') ?> — Powered by QEMU/KVM &amp; Tailscale
  </p>
</div>

<?php else: ?>
<!-- ══ OWNER PANEL ══════════════════════════════════════════════════════ -->
<nav class="navbar">
  <div class="nav-brand"><i class="fa-solid fa-server"></i>DenizHosting</div>
  <div class="nav-right">
    <div class="owner-chip">
      <i class="fa-solid fa-crown"></i>
      <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
      <span class="badge-owner">OWNER</span>
    </div>
    <a href="?action=logout" class="btn btn-ghost btn-sm"><i class="fa fa-right-from-bracket"></i> Logout</a>
  </div>
</nav>
<div class="container">
  <div class="owner-banner">
    <div class="owner-banner-left">
      <i class="fa-solid fa-crown"></i>
      <span><strong>Owner Mode Active</strong> — Full control over all instances and settings.</span>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="toggle_work_mode">
      <button type="submit" class="btn btn-sm <?= $workMode ? 'btn-success' : 'btn-warning' ?>">
        <i class="fa fa-<?= $workMode ? 'eye' : 'eye-slash' ?>"></i>
        <?= $workMode ? 'Disable Maintenance Mode' : 'Enable Maintenance Mode' ?>
      </button>
    </form>
  </div>

  <div class="stats-row">
    <div class="stat-card"><div class="stat-label">Total VPS</div><div class="stat-value"><?= $totalVps ?></div></div>
    <div class="stat-card"><div class="stat-label">Online</div><div class="stat-value green"><?= $onlineVps ?></div></div>
    <div class="stat-card"><div class="stat-label">Installing</div><div class="stat-value orange"><?= $installingVps ?></div></div>
    <div class="stat-card"><div class="stat-label">Offline</div><div class="stat-value red"><?= $totalVps - $onlineVps - $installingVps ?></div></div>
  </div>

  <div class="page-header">
    <div class="page-title">VPS Instances <span><?= $totalVps ?> total</span></div>
    <form method="POST"><input type="hidden" name="action" value="create_vps">
      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Create VPS</button>
    </form>
  </div>

  <?php if (empty($vpsList)): ?>
  <div class="card"><div class="empty-state">
    <i class="fa-solid fa-server"></i>
    <h3>No VPS Instances Yet</h3>
    <p>Create your first VPS — auto-provisioned with 7 vCores, 4 GB RAM, and 1 TB storage.</p>
    <form method="POST"><input type="hidden" name="action" value="create_vps">
      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Create First VPS</button>
    </form>
  </div></div>
  <?php else: ?>
  <div class="vps-grid">
  <?php foreach ($vpsList as $vps):
    $st = $vps['status'];
    $isOnline = $st === 'online';
    $isInstalling = in_array($st, ['installing','provisioning']);
    $hClass = $isOnline ? 'online' : ($isInstalling ? 'installing' : 'offline');
    $hIcon  = $isInstalling ? 'fa-gear' : 'fa-heart';
  ?>
  <div class="vps-card <?= $st ?>">
    <div class="vps-header">
      <div>
        <div class="vps-name"><?= htmlspecialchars($vps['vm_name']) ?></div>
        <div style="font-size:.72rem;color:var(--text2);margin-top:2px;">
          <i class="fa fa-user" style="font-size:.65rem;"></i> <?= htmlspecialchars($vps['username']) ?>
        </div>
      </div>
      <div class="vps-status-row">
        <i class="fa-solid <?= $hIcon ?> heartbeat-icon <?= $hClass ?>"></i>
        <span class="status-badge <?= $st ?>"><?= $st ?></span>
      </div>
    </div>
    <div class="vps-body">
      <div class="vps-specs">
        <div class="spec-item"><i class="fa fa-microchip"></i><strong><?= $vps['cores'] ?></strong>&nbsp;vCores</div>
        <div class="spec-item"><i class="fa fa-memory"></i><strong><?= number_format($vps['ram_mb']/1024,1) ?>GB</strong>&nbsp;RAM</div>
        <div class="spec-item"><i class="fa fa-hard-drive"></i><strong><?= $vps['disk_gb'] ?>GB</strong>&nbsp;SSD</div>
        <div class="spec-item"><i class="fa fa-clock"></i><?= date('M j, Y', strtotime($vps['created_at'])) ?></div>
      </div>
      <?php if (!empty($vps['tailscale_auth_url']) && !$isOnline): ?>
      <div class="ts-popup">
        <i class="fa-solid fa-link"></i>
        <div>
          <h5>Tailscale Authentication Required</h5>
          <p>Click below and approve the device in your Tailscale dashboard to bring this VPS online.</p>
          <a href="<?= htmlspecialchars($vps['tailscale_auth_url']) ?>" target="_blank" class="btn btn-primary btn-sm">
            <i class="fa fa-arrow-up-right-from-square"></i> Authenticate Tailscale
          </a>
        </div>
      </div>
      <?php endif; ?>
      <div class="console-wrapper" style="margin-top:1rem;">
        <div class="console-box <?= $isInstalling ? 'blurred' : '' ?>">
          <?php if ($isOnline): ?>
            <span style="color:#6ee7b7;">● Connected via Tailscale</span><br>
            <span style="color:#64748b;">$ </span>Welcome to <?= htmlspecialchars($vps['vm_name']) ?><br>
            <span style="color:#64748b;">$ </span>Ubuntu 22.04 LTS — KVM/QEMU<br>
            <span style="color:#64748b;">$ </span>SSH: <strong style="color:#a3e635;">ssh ubuntu@<?= htmlspecialchars($vps['tailscale_ip'] ?? 'N/A') ?></strong>
          <?php elseif ($isInstalling): ?>
            <span style="color:#fb923c;">● Provisioning...</span><br>
            Downloading cloud image...<br>Configuring cloud-init...<br>Starting Tailscale...
          <?php else: ?>
            <span style="color:#f87171;">● VM Offline</span><br>
            <span style="color:#64748b;">$ </span>Connection unavailable
          <?php endif; ?>
        </div>
        <?php if ($isInstalling): ?>
        <div class="console-overlay">
          <div class="spinner"></div>
          <h4>Installing…</h4>
          <p>Provisioning VM — 2–5 minutes.<br>Page auto-refreshes.</p>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <div class="vps-footer">
      <div class="vps-ip">
        <?php if ($isOnline && !empty($vps['tailscale_ip'])): ?>
          <i class="fa fa-network-wired" style="color:var(--green);"></i> Tailscale IP: <strong><?= htmlspecialchars($vps['tailscale_ip']) ?></strong>
        <?php elseif ($isInstalling): ?>
          <i class="fa fa-clock" style="color:var(--orange);"></i> Awaiting Tailscale…
        <?php else: ?>
          <i class="fa fa-circle-xmark" style="color:var(--red);"></i> No connection
        <?php endif; ?>
      </div>
      <form method="POST" onsubmit="return confirm('Permanently delete this VPS and all its data?');">
        <input type="hidden" name="action" value="delete_vps">
        <input type="hidden" name="vps_id" value="<?= $vps['id'] ?>">
        <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</button>
      </form>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if (!empty($allUsers)): ?>
  <div class="page-header" style="margin-top:2.5rem;">
    <div class="page-title">Users <span><?= count($allUsers) ?> accounts</span></div>
  </div>
  <div class="card"><div class="table-wrap"><table>
    <thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Joined</th></tr></thead>
    <tbody>
    <?php foreach ($allUsers as $u): ?>
    <tr>
      <td style="color:var(--text2);"><?= $u['id'] ?></td>
      <td><?= htmlspecialchars($u['username']) ?></td>
      <td><?= $u['role']==='owner' ? '<span class="badge-owner">OWNER</span>' : '<span style="color:var(--text2);font-size:.78rem;">user</span>' ?></td>
      <td style="color:var(--text2);"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div></div>
  <?php endif; ?>

  <p style="text-align:center;font-size:.72rem;color:var(--text2);margin-top:2.5rem;padding-bottom:1rem;">
    DenizHosting &copy; <?= date('Y') ?> — Powered by QEMU/KVM &amp; Tailscale
  </p>
</div>
<?php if ($installingVps > 0): ?>
<script>setTimeout(()=>location.reload(),10000);</script>
<?php endif; ?>
<?php endif; ?>

<!-- ══ OWNER LOGIN MODAL — present on every page ══════════════════════ -->
<div class="modal-overlay" id="ownerModal">
  <div class="modal-box">
    <button class="modal-close" onclick="closeModal()" title="Close"><i class="fa fa-xmark"></i></button>
    <div class="modal-header">
      <i class="fa-solid fa-crown"></i>
      <h2>Owner Mode</h2>
      <p>Sign in with your owner credentials to manage the panel.</p>
    </div>
    <?php if ($loginError): ?>
    <div class="error-msg"><i class="fa fa-circle-exclamation"></i> <?= htmlspecialchars($loginError) ?></div>
    <?php endif; ?>
    <form method="POST">
      <input type="hidden" name="action" value="owner_login">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" placeholder="Owner username" autocomplete="username" required>
      </div>
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:.4rem;padding:11px;">
        <i class="fa fa-right-to-bracket"></i> Sign In as Owner
      </button>
    </form>
  </div>
</div>

<script>
function openModal(){
  document.getElementById('ownerModal').classList.add('open');
  setTimeout(()=>{const f=document.querySelector('#ownerModal input[name="username"]');if(f)f.focus();},60);
}
function closeModal(){document.getElementById('ownerModal').classList.remove('open');}
document.getElementById('ownerModal').addEventListener('click',function(e){if(e.target===this)closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
<?php if ($loginError): ?>document.addEventListener('DOMContentLoaded',openModal);<?php endif; ?>
</script>
</body>
</html>
