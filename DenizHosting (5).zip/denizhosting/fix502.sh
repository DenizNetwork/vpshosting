#!/usr/bin/env bash
# =============================================================================
# DenizHosting — 502 Bad Gateway Fixer
# Run this if you see a Cloudflare 502 error after installation.
# Usage: sudo bash fix502.sh
# =============================================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $*"; }
info() { echo -e "${CYAN}[→]${NC} $*"; }
warn() { echo -e "${YELLOW}[!]${NC} $*"; }
ok()   { echo -e "${GREEN}[OK]${NC}  $*"; }
fail() { echo -e "${RED}[✗]${NC}  $*"; }

[[ $EUID -ne 0 ]] && echo "Run as root: sudo bash fix502.sh" && exit 1

WEB_ROOT="/var/www/denizhosting"

echo -e "\n${BOLD}${CYAN}DenizHosting — 502 Diagnostic & Auto-Fix${NC}\n"

# =============================================================================
echo -e "${BOLD}── Diagnostics ──────────────────────────────────────${NC}\n"

# 1. Nginx running?
if systemctl is-active --quiet nginx; then
    ok "Nginx is running"
else
    fail "Nginx is NOT running"
    info "Starting Nginx..."
    systemctl start nginx && log "Nginx started" || warn "Nginx failed to start — check: journalctl -u nginx"
fi

# 2. PHP-FPM running?
if systemctl is-active --quiet php8.1-fpm; then
    ok "PHP 8.1-FPM is running"
else
    fail "PHP 8.1-FPM is NOT running"
    info "Starting PHP-FPM..."
    systemctl start php8.1-fpm && log "PHP-FPM started" || warn "PHP-FPM failed — check: journalctl -u php8.1-fpm"
fi

# 3. cloudflared running?
if systemctl is-active --quiet cloudflared; then
    ok "cloudflared is running"
else
    fail "cloudflared is NOT running"
    info "Starting cloudflared..."
    systemctl start cloudflared && log "cloudflared started" || warn "cloudflared failed — check: journalctl -u cloudflared"
fi

# 4. MariaDB running?
if systemctl is-active --quiet mariadb; then
    ok "MariaDB is running"
else
    fail "MariaDB is NOT running"
    systemctl start mariadb && log "MariaDB started" || warn "MariaDB failed"
fi

# 5. Web root exists?
if [[ -f "${WEB_ROOT}/index.php" ]]; then
    ok "Web root present: ${WEB_ROOT}/index.php"
else
    fail "index.php missing from ${WEB_ROOT}"
fi

# 6. PHP socket exists?
PHP_SOCK="/run/php/php8.1-fpm.sock"
if [[ -S "$PHP_SOCK" ]]; then
    ok "PHP-FPM socket exists: ${PHP_SOCK}"
else
    fail "PHP-FPM socket missing: ${PHP_SOCK}"
    info "Restarting PHP-FPM..."
    systemctl restart php8.1-fpm
    sleep 1
    [[ -S "$PHP_SOCK" ]] && log "Socket created" || warn "Still no socket — PHP-FPM may have errors"
fi

# 7. Local HTTP test
echo ""
info "Testing local HTTP on port 80..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://127.0.0.1/ 2>/dev/null || echo "000")
if echo "$HTTP_CODE" | grep -qE "^(200|301|302)"; then
    ok "Nginx responds on port 80 (HTTP $HTTP_CODE)"
elif [[ "$HTTP_CODE" == "404" ]]; then
    ok "Nginx responds on port 80 (HTTP 404 — panel reachable, check PHP)"
else
    fail "No response on port 80 (got: ${HTTP_CODE})"
fi

# 8. Port 80 listener check
echo ""
info "Checking port 80 listener..."
if ss -tlnp 2>/dev/null | grep -q ':80 '; then
    ok "Something is listening on port 80:"
    ss -tlnp | grep ':80 '
else
    fail "Nothing listening on port 80!"
fi

# =============================================================================
echo -e "\n${BOLD}── Auto-Fix: Rewriting Nginx Config ────────────────${NC}\n"

info "Rewriting Nginx vhost to listen on all interfaces (port 80)..."
cat > /etc/nginx/sites-available/denizhosting << 'NGINXEOF'
# DenizHosting — served via Cloudflare Tunnel
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    root /var/www/denizhosting;
    index index.php;

    access_log /var/log/nginx/denizhosting_access.log;
    error_log  /var/log/nginx/denizhosting_error.log;

    # Pass real visitor IP from Cloudflare headers
    set_real_ip_from 173.245.48.0/20;
    set_real_ip_from 103.21.244.0/22;
    set_real_ip_from 103.22.200.0/22;
    set_real_ip_from 103.31.4.0/22;
    set_real_ip_from 141.101.64.0/18;
    set_real_ip_from 108.162.192.0/18;
    set_real_ip_from 190.93.240.0/20;
    set_real_ip_from 188.114.96.0/20;
    set_real_ip_from 197.234.240.0/22;
    set_real_ip_from 198.41.128.0/17;
    set_real_ip_from 162.158.0.0/15;
    set_real_ip_from 104.16.0.0/13;
    set_real_ip_from 104.24.0.0/14;
    set_real_ip_from 172.64.0.0/13;
    set_real_ip_from 131.0.72.0/22;
    real_ip_header CF-Connecting-IP;

    add_header X-Frame-Options        "SAMEORIGIN"  always;
    add_header X-Content-Type-Options "nosniff"     always;

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_hide_header X-Powered-By;
    }

    location ~ ^/(config|db)\.php$ { deny all; return 404; }
    location / { try_files $uri $uri/ /index.php?$query_string; }
    location ~ /\. { deny all; }
}
NGINXEOF

# Remove ALL other enabled sites (default, etc.)
info "Removing conflicting sites from sites-enabled..."
REMOVED=0
for f in /etc/nginx/sites-enabled/*; do
    fname="$(basename "$f")"
    if [[ "$fname" != "denizhosting" ]]; then
        rm -f "$f"
        warn "Removed conflicting site: $fname"
        REMOVED=$((REMOVED+1))
    fi
done
[[ $REMOVED -eq 0 ]] && log "No conflicting sites found"

ln -sf /etc/nginx/sites-available/denizhosting /etc/nginx/sites-enabled/denizhosting

info "Testing Nginx config..."
if nginx -t 2>&1; then
    info "Restarting Nginx..."
    systemctl restart nginx
    sleep 1
    log "Nginx restarted"
else
    warn "Nginx config test failed — check the error above"
    exit 1
fi

# Final test
sleep 1
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://127.0.0.1/ 2>/dev/null || echo "000")
echo ""
if echo "$HTTP_CODE" | grep -qE "^(200|301|302|404)"; then
    echo -e "${GREEN}${BOLD}╔══════════════════════════════════════════════════╗"
    echo -e "║  ✓  Nginx is responding — 502 should be fixed!   ║"
    echo -e "╚══════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  HTTP response: ${GREEN}${HTTP_CODE}${NC} on http://127.0.0.1/"
    echo -e "  Cloudflare Tunnel will now successfully reach Nginx."
    echo -e "  Wait ~30 seconds then refresh your browser.\n"
else
    echo -e "${RED}${BOLD}╔══════════════════════════════════════════════════╗"
    echo -e "║  Still not responding (HTTP ${HTTP_CODE}) — manual check  ║"
    echo -e "╚══════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  Run these to investigate:"
    echo -e "  ${CYAN}sudo systemctl status nginx${NC}"
    echo -e "  ${CYAN}sudo journalctl -u nginx --no-pager -n 30${NC}"
    echo -e "  ${CYAN}sudo nginx -t${NC}"
    echo -e "  ${CYAN}sudo systemctl status cloudflared${NC}"
    echo ""
fi

echo -e "${BOLD}── Service Status Summary ───────────────────────────${NC}"
for svc in nginx php8.1-fpm cloudflared mariadb; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        echo -e "  ${GREEN}●${NC} ${svc}"
    else
        echo -e "  ${RED}●${NC} ${svc}  ${RED}(inactive)${NC}"
    fi
done
echo ""
