#!/usr/bin/env bash
set -euo pipefail
ACTION="${1:-}"
ID="${2:-}"
NAME="${3:-}"
OWNER="${4:-}"
PHP_CONF="/var/www/denizhosting/config.php"
DB_NAME="$(php -r "include '$PHP_CONF'; echo DB_NAME;")"
DB_USER="$(php -r "include '$PHP_CONF'; echo DB_USER;")"
DB_PASS="$(php -r "include '$PHP_CONF'; echo DB_PASS;")"
DOMAIN="$(php -r "include '$PHP_CONF'; echo PANEL_DOMAIN;")"
IMAGES_DIR="/opt/denizhosting/images"
VMS_DIR="/opt/denizhosting/vms"
LOG_DIR="/var/log/denizhosting"
mkdir -p "$IMAGES_DIR" "$VMS_DIR" "$LOG_DIR" "/opt/denizhosting/tmp"
PORT=$((22000 + ID))
if [[ "$ACTION" = "delete" ]]; then
  VM_NAME="$(mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -N -B -e "SELECT name FROM vps WHERE id=$ID LIMIT 1")"
  SSH_PORT="$(mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -N -B -e "SELECT ssh_port FROM vps WHERE id=$ID LIMIT 1")"
  if [[ -n "${VM_NAME:-}" ]]; then
    if virsh dominfo "$VM_NAME" >/dev/null 2>&1; then
      virsh destroy "$VM_NAME" >/dev/null 2>&1 || true
      virsh undefine "$VM_NAME" --remove-all-storage >/dev/null 2>&1 || true
    fi
  fi
  IPT_DST="$(iptables -t nat -S PREROUTING | grep "dport ${SSH_PORT}" | sed -E 's/.*--to-destination ([0-9\.]+):22.*/\1/' || true)"
  if [[ -n "$SSH_PORT" ]]; then
    iptables -t nat -D PREROUTING -p tcp --dport "$SSH_PORT" -j DNAT --to-destination "$IPT_DST":22 >/dev/null 2>&1 || true
  fi
  if [[ -n "$IPT_DST" ]]; then
    iptables -D FORWARD -p tcp -d "$IPT_DST" --dport 22 -j ACCEPT >/dev/null 2>&1 || true
  fi
  mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "DELETE FROM vps WHERE id=$ID"
  exit 0
fi
BASE_IMG="$IMAGES_DIR/ubuntu-22.04-server-cloudimg-amd64.img"
if [[ ! -f "$BASE_IMG" ]]; then
  curl -L -o "$BASE_IMG" "https://cloud-images.ubuntu.com/jammy/current/jammy-server-cloudimg-amd64.img"
fi
DISK="$VMS_DIR/${NAME}.qcow2"
if [[ -f "$DISK" ]]; then rm -f "$DISK"; fi
qemu-img create -f qcow2 -b "$BASE_IMG" -F qcow2 "$DISK" 1T
TMP="/opt/denizhosting/tmp/$ID"
mkdir -p "$TMP"
cat > "$TMP/user-data" <<'YAML'
ssh_pwauth: true
users:
  - name: ubuntu
    groups: sudo
    shell: /bin/bash
    sudo: ALL=(ALL) NOPASSWD:ALL
chpasswd:
  list: |
    ubuntu:ubuntu
  expire: false
YAML
cat > "$TMP/meta-data" <<EOF
instance-id: ${NAME}
local-hostname: ${NAME}
EOF
SEED="$VMS_DIR/${NAME}-seed.iso"
if command -v cloud-localds >/dev/null 2>&1; then
  cloud-localds "$SEED" "$TMP/user-data" "$TMP/meta-data"
else
  genisoimage -output "$SEED" -volid cidata -joliet -rock "$TMP/user-data" "$TMP/meta-data"
fi
virt-install \
  --name "$NAME" \
  --memory 4000 \
  --vcpus 7 \
  --disk path="$DISK",format=qcow2,bus=virtio \
  --disk path="$SEED",device=cdrom \
  --osinfo detect=on,require=off \
  --graphics none \
  --network network=default,model=virtio \
  --import \
  --noautoconsole
sleep 5
tries=60
IP=""
while [[ $tries -gt 0 ]]; do
  IP="$(virsh domifaddr "$NAME" --source lease 2>/dev/null | awk '/ipv4/ {print $4}' | cut -d/ -f1 | head -n1 || true)"
  if [[ -z "$IP" ]]; then
    IP="$(virsh domifaddr "$NAME" 2>/dev/null | awk '/ipv4/ {print $4}' | cut -d/ -f1 | head -n1 || true)"
  fi
  if [[ -n "$IP" ]]; then break; fi
  sleep 5
  tries=$((tries-1))
done
sysctl -w net.ipv4.ip_forward=1 >/dev/null
iptables -t nat -A PREROUTING -p tcp --dport "$PORT" -j DNAT --to-destination "$IP":22
iptables -A FORWARD -p tcp -d "$IP" --dport 22 -j ACCEPT
mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "UPDATE vps SET ip='${IP}', ssh_port=${PORT}, status='online', updated_at=NOW() WHERE id=${ID}"
exit 0
