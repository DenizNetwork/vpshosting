#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run as root"; exit 1; fi
menu() {
  echo "[1] Install DenizHosting"
  echo "[2] Uninstall DenizHosting"
  echo "[3] Exit"
  read -rp "Select: " c
  case "$c" in
    1) install ;; 2) uninstall ;; *) exit 0 ;;
  esac
}
detect_os() {
  . /etc/os-release
  OS_ID="$ID"
  CODENAME="${VERSION_CODENAME:-}"
}
install_packages() {
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y curl ca-certificates gnupg lsb-release qemu-kvm libvirt-daemon-system libvirt-clients virtinst cloud-image-utils nginx php-fpm php-mysql php-curl php-mbstring php-xml php-zip mariadb-server
  systemctl enable --now libvirtd
}
setup_db() {
  systemctl enable --now mariadb
  DB_NAME="denizhosting"
  DB_USER="denizhost_user"
  DB_PASS="$(openssl rand -hex 12)"
  mysql -uroot -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
  mysql -uroot -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
  mysql -uroot -e "GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'localhost'; FLUSH PRIVILEGES;"
  mysql -uroot "${DB_NAME}" < /tmp/denizhosting/schema.sql
  echo "$DB_NAME" > /tmp/denizhosting/db_name
  echo "$DB_USER" > /tmp/denizhosting/db_user
  echo "$DB_PASS" > /tmp/denizhosting/db_pass
}
write_web() {
  mkdir -p /var/www/denizhosting
  cp -r "$(pwd)/web/." /var/www/denizhosting/
  chown -R www-data:www-data /var/www/denizhosting
  DB_NAME="$(cat /tmp/denizhosting/db_name)"
  DB_USER="$(cat /tmp/denizhosting/db_user)"
  DB_PASS="$(cat /tmp/denizhosting/db_pass)"
  DOMAIN_INPUT="$PANEL_DOMAIN"
  php -r "\$p='/var/www/denizhosting/config.php';\$c=file_get_contents(\$p);\$c=str_replace('change_me','${DB_PASS}',\$c);\$c=str_replace(\"define('DB_USER','denizhost_user');\",\"define('DB_USER','${DB_USER}');\",\$c);\$c=str_replace(\"define('DB_NAME','denizhosting');\",\"define('DB_NAME','${DB_NAME}');\",\$c);if('${DOMAIN_INPUT}'!=''){ \$c=preg_replace(\"/define\\('PANEL_DOMAIN'.*;/\",\"define('PANEL_DOMAIN','${DOMAIN_INPUT}');\",\$c);}file_put_contents(\$p,\$c);"
  API_TOKEN="$(openssl rand -hex 16)"
  mysql -uroot "$DB_NAME" -e "UPDATE settings SET api_token='${API_TOKEN}'"
}
setup_dirs_perms() {
  mkdir -p /opt/denizhosting/scripts /opt/denizhosting/images /opt/denizhosting/vms /var/log/denizhosting
  cp -r "$(pwd)/scripts/." /opt/denizhosting/scripts/
  chmod +x /opt/denizhosting/scripts/*.sh
  printf 'www-data ALL=(ALL) NOPASSWD: %s\n' "/opt/denizhosting/scripts/create_vps.sh" >/etc/sudoers.d/denizhosting
}
setup_nginx() {
  cp "$(pwd)/config/nginx-denizhosting.conf" /etc/nginx/sites-available/denizhosting.conf
  ln -sf /etc/nginx/sites-available/denizhosting.conf /etc/nginx/sites-enabled/denizhosting.conf
  rm -f /etc/nginx/sites-enabled/default || true
  systemctl restart nginx php*-fpm
}
setup_tunnel() {
  read -rp "Panel domain (e.g. vps.yourdomain.com): " PANEL_DOMAIN
  read -rp "Cloudflare Tunnel token: " CF_TOKEN
  curl -L "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb" -o /tmp/cloudflared.deb
  dpkg -i /tmp/cloudflared.deb || true
  cloudflared service install "$CF_TOKEN"
  mkdir -p /etc/cloudflared
  cat >/etc/cloudflared/config.yml <<EOF
tunnel: $(cloudflared tunnel list 2>/dev/null | awk 'NR==2{print $1}')
credentials-file: /root/.cloudflared/*.json
ingress:
  - hostname: ${PANEL_DOMAIN}
    service: http://localhost:80
  - service: http_status:404
EOF
  systemctl enable --now cloudflared
}
install() {
  mkdir -p /tmp/denizhosting
  cp -r "$(pwd)/sql/." /tmp/denizhosting/
  detect_os
  install_packages
  setup_db
  setup_tunnel
  write_web
  setup_dirs_perms
  setup_nginx
  echo "Done"
}
uninstall() {
  read -rp "Type CONFIRM to uninstall: " C
  if [[ "$C" != "CONFIRM" ]]; then exit 1; fi
  systemctl stop cloudflared || true
  systemctl disable cloudflared || true
  apt-get purge -y cloudflared || true
  rm -rf /etc/cloudflared || true
  systemctl stop nginx || true
  systemctl stop php*-fpm || true
  systemctl stop mariadb || true
  virsh list --all | awk 'NR>2 {print $2}' | while read -r vm; do virsh destroy "$vm" || true; virsh undefine "$vm" --remove-all-storage || true; done
  apt-get purge -y nginx php* mariadb-server qemu-kvm libvirt-* virtinst cloud-image-utils || true
  rm -rf /var/www/denizhosting /opt/denizhosting /var/log/denizhosting
  rm -f /etc/nginx/sites-enabled/denizhosting.conf /etc/nginx/sites-available/denizhosting.conf
  ufw --force reset || true
  echo "Uninstalled"
}
menu
