#!/usr/bin/env bash
set -euo pipefail
echo "Checking nginx"
nginx -t || true
ss -tlnp | grep :80 || true
echo "Checking cloudflared"
systemctl status cloudflared --no-pager -n 20 || true
journalctl -u cloudflared --no-pager -n 40 || true
echo "Ensure Public Hostname is configured in Cloudflare dashboard"
