<?php
require_once __DIR__ . '/db.php';
header('Content-Type: application/json');
$method = $_SERVER['REQUEST_METHOD'];
if ($method !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok'=>false,'error'=>'method']);
    exit;
}
$token = isset($_POST['token']) ? $_POST['token'] : '';
$vps_id = isset($_POST['vps_id']) ? intval($_POST['vps_id']) : 0;
$ip = isset($_POST['ip']) ? trim($_POST['ip']) : null;
$status = isset($_POST['status']) ? trim($_POST['status']) : null;
if (!$vps_id) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'vps_id']);
    exit;
}
try {
    $stmt = $pdo->prepare('SELECT api_token FROM settings LIMIT 1');
    $stmt->execute();
    $row = $stmt->fetch();
    $api = $row ? $row['api_token'] : '';
    if (!$api || !$token || !hash_equals($api, $token)) {
        http_response_code(401);
        echo json_encode(['ok'=>false,'error'=>'auth']);
        exit;
    }
    if ($ip !== null) {
        $s = $pdo->prepare('UPDATE vps SET ip=?,updated_at=NOW() WHERE id=?');
        $s->execute([$ip,$vps_id]);
    }
    if ($status !== null) {
        $s = $pdo->prepare('UPDATE vps SET status=?,updated_at=NOW() WHERE id=?');
        $s->execute([$status,$vps_id]);
    }
    echo json_encode(['ok'=>true]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok'=>false]);
}
