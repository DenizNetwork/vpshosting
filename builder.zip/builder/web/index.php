<?php
session_start();
require_once __DIR__ . '/db.php';
$owner_user = 'DenizHost';
$owner_pass = 'Denizmax';
function is_owner(){return isset($_SESSION['owner'])&&$_SESSION['owner']===true;}
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action = isset($_POST['action'])?$_POST['action']:'';
    if ($action==='login') {
        $u = isset($_POST['username'])?$_POST['username']:'';
        $p = isset($_POST['password'])?$_POST['password']:'';
        if ($u===$owner_user && $p===$owner_pass) {
            $_SESSION['owner']=true;
        } else {
            $_SESSION['login_error']='Invalid credentials';
        }
        header('Location: index.php');exit;
    }
    if ($action==='logout') {session_destroy();header('Location: index.php');exit;}
    if ($action==='toggle_maintenance' && is_owner()) {
        $s=$pdo->query('SELECT maintenance FROM settings LIMIT 1')->fetch();
        $m=$s?intval($s['maintenance']):0;
        $n=$m?0:1;
        $stmt=$pdo->prepare('UPDATE settings SET maintenance=?,updated_at=NOW()');$stmt->execute([$n]);
        header('Location: index.php');exit;
    }
    if ($action==='create_vps' && is_owner()) {
        $name=isset($_POST['name'])&&$_POST['name']!==''?trim($_POST['name']):null;
        $stmt=$pdo->prepare('INSERT INTO vps (name,owner,status,vcpu,ram_mb,disk_gb,created_at,updated_at) VALUES (?,?,?,?,?,?,NOW(),NOW())');
        $n=$name?:'vps';
        $stmt->execute([$n,$owner_user,'provisioning',7,4000,1024]);
        $id=$pdo->lastInsertId();
        $realname=$n.'-'.$id;
        $pdo->prepare('UPDATE vps SET name=? WHERE id=?')->execute([$realname,$id]);
        $log='/var/log/denizhosting/vps-'.$id.'.log';
        $cmd='sudo '.escapeshellarg(SCRIPTS_PATH.'/create_vps.sh').' create '.intval($id).' '.escapeshellarg($realname).' '.escapeshellarg($owner_user).' > '.escapeshellarg($log).' 2>&1 &';
        shell_exec($cmd);
        header('Location: index.php');exit;
    }
    if ($action==='delete_vps' && is_owner()) {
        $id=intval($_POST['id']);
        $log='/var/log/denizhosting/vps-'.$id.'.log';
        $cmd='sudo '.escapeshellarg(SCRIPTS_PATH.'/create_vps.sh').' delete '.intval($id).' > '.escapeshellarg($log).' 2>&1 &';
        shell_exec($cmd);
        header('Location: index.php');exit;
    }
}
$settings=$pdo->query('SELECT maintenance,api_token,domain FROM settings LIMIT 1')->fetch();
$maintenance=$settings?intval($settings['maintenance']):0;
$domain=$settings&&$settings['domain']?$settings['domain']:PANEL_DOMAIN;
$stats=$pdo->query("SELECT status,COUNT(*) c FROM vps GROUP BY status")->fetchAll();
$counts=['online'=>0,'provisioning'=>0,'offline'=>0];
foreach($stats as $r){$counts[$r['status']]=$r['c'];}
$vps=$pdo->query('SELECT * FROM vps ORDER BY id DESC')->fetchAll();
?><!doctype html>
<html>
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DenizHosting</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1220;color:#e6efff;font-family:Inter,system-ui,Segoe UI,Arial}
.nav{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;background:rgba(13,19,35,.7);backdrop-filter:blur(8px);position:sticky;top:0}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:18px}
.btn{background:#3b82f6;border:none;color:#fff;padding:10px 14px;border-radius:10px;cursor:pointer;transition:.2s}
.btn:hover{filter:brightness(1.1)}
.btn.warn{background:#f59e0b}
.btn.danger tilt{background:#ef4444}
.grid{display:grid;gap:16px}
.hero{display:grid;min-height:60vh;place-items:center;text-align:center;padding:40px}
.card{background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:18px}
.row{display:flex;gap:12px;flex-wrap:wrap}
.stat{flex:1;min-width:180px;text-align:center;padding:16px;border-radius:14px;background:rgba(255,255,255,.06)}
.badge{display:inline-block;padding:4px 8px;border-radius:999px;font-size:12px}
.green{color:#22c55e}.red{color:#ef4444}.orange{color:#f59e0b}
.muted{color:#9fb0d3}
.vps-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px}
.footer{padding:30px;text-align:center;color:#90a2c3}
.modal{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.5)}
.modal.show{display:flex}
.modal .panel{width:360px;background:#0f172a;border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:20px}
input,select{width:100%;padding:10px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:rgba(255,255,255,.04);color:#e6efff}
.owner-chip{display:flex;align-items:center;gap:10px;background:rgba(255,255,255,.06);border-radius:999px;padding:6px 10px}
.owner{background:#f59e0b;color:#111827}
.console{background:#0a0f1c;color:#9be4a7;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;border-radius:12px;padding:12px;min-height:80px}
.blink{animation:blink 1s infinite}@keyframes blink{50%{opacity:.5}}
</style>
</head>
<body>
<div class="nav">
  <div class="brand">🖥️ DenizHosting</div>
  <div>
    <?php if(is_owner()): ?>
      <span class="owner-chip">👑 <?php echo htmlspecialchars($owner_user); ?> <span class="badge owner">OWNER</span></span>
      <form method="post" style="display:inline">
        <input type="hidden" name="action" value="toggle_maintenance">
        <button class="btn warn" type="submit"><?php echo $maintenance?'Disable Maintenance':'Enable Maintenance'; ?></button>
      </form>
      <form method="post" style="display:inline">
        <input type="hidden" name="action" value="logout">
        <button class="btn" type="submit">Logout</button>
      </form>
    <?php else: ?>
      <button class="btn" id="ownerBtn">Owner Mode</button>
    <?php endif; ?>
  </div>
</div>
<?php if(!$maintenance && !is_owner()): ?>
  <div class="hero">
    <div class="card" style="max-width:860px;margin:auto">
      <h1 style="margin:0 0 10px 0;font-size:40px">Self‑Hosted VPS Panel</h1>
      <p class="muted">Create and manage KVM virtual machines on your own server with a clean, modern UI.</p>
      <div class="row" style="margin-top:18px">
        <div class="stat">⚙️ CPU <div class="muted">7 vCores</div></div>
        <div class="stat">🧠 RAM <div class="muted">4 GB</div></div>
        <div class="stat">💾 Storage <div class="muted">1 TB qcow2</div></div>
        <div class="stat">🐧 OS <div class="muted">Ubuntu 22.04</div></div>
        <div class="stat">🔒 Access <div class="muted">SSH with port mapping</div></div>
        <div class="stat">⚡ Speed <div class="muted">KVM + virtio</div></div>
      </div>
      <div style="margin-top:16px"><button class="btn" id="ownerBtn2">Owner Mode</button></div>
    </div>
  </div>
<?php elseif($maintenance && !is_owner()): ?>
  <div class="hero">
    <div class="card" style="max-width:560px;margin:auto;text-align:center">
      <div style="font-size:64px" class="blink">🔧</div>
      <h2>Under Maintenance</h2>
      <p class="muted">The owner is working on the panel.</p>
      <div style="margin-top:10px"><button class="btn" id="ownerBtn3">Owner Mode</button></div>
    </div>
  </div>
<?php else: ?>
  <div style="padding:20px;max-width:1200px;margin:auto">
    <div class="card" style="margin-bottom:16px">
      <div class="row">
        <div class="stat"><div>Total VPS</div><div style="font-size:28px"><?php echo $counts['online']+$counts['offline']+$counts['provisioning']; ?></div></div>
        <div class="stat"><div class="green">Online</div><div style="font-size:28px" class="green"><?php echo $counts['online']; ?></div></div>
        <div class="stat"><div class="orange">Installing</div><div style="font-size:28px" class="orange"><?php echo $counts['provisioning']; ?></div></div>
        <div class="stat"><div class="red">Offline</div><div style="font-size:28px" class="red"><?php echo $counts['offline']; ?></div></div>
      </div>
    </div>
    <div class="card" style="margin-bottom:16px">
      <form method="post" class="row" style="align-items:end">
        <input type="hidden" name="action" value="create_vps">
        <div style="flex:1;min-width:260px">
          <label>VM name</label>
          <input name="name" placeholder="vps">
        </div>
        <button class="btn" type="submit">Create VPS</button>
      </form>
    </div>
    <div class="vps-grid">
      <?php foreach($vps as $vm): ?>
        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div style="font-weight:600"><?php echo htmlspecialchars($vm['name']); ?></div>
            <?php if($vm['status']==='online'): ?>
              <div class="badge green">Online</div>
            <?php elseif($vm['status']==='provisioning'): ?>
              <div class="badge orange">Installing</div>
            <?php else: ?>
              <div class="badge red">Offline</div>
            <?php endif; ?>
          </div>
          <div class="muted" style="margin-top:6px">Owner: <?php echo htmlspecialchars($vm['owner']); ?></div>
          <div class="muted" style="margin-top:6px">vCPU <?php echo intval($vm['vcpu']); ?> • RAM <?php echo intval($vm['ram_mb']); ?> MB • Disk <?php echo intval($vm['disk_gb']); ?> GB</div>
          <div class="console" style="margin-top:10px">
            <?php if($vm['status']==='online' && $vm['ssh_port']): ?>
              ssh -p <?php echo intval($vm['ssh_port']); ?> ubuntu@<?php echo htmlspecialchars($domain); ?>
            <?php elseif($vm['status']==='provisioning'): ?>
              Installing...
            <?php else: ?>
              Offline
            <?php endif; ?>
          </div>
          <div class="muted" style="margin-top:6px"><?php echo $vm['ip']?'IP '.$vm['ip']:'IP pending'; ?></div>
          <div style="margin-top:10px;display:flex;gap:8px">
            <form method="post" onsubmit="return confirm('Delete this VPS?')">
              <input type="hidden" name="action" value="delete_vps">
              <input type="hidden" name="id" value="<?php echo intval($vm['id']); ?>">
              <button class="btn" type="submit">Delete</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php if($counts['provisioning']>0): ?>
    <script>setInterval(()=>location.reload(),10000)</script>
  <?php endif; ?>
<?php endif; ?>
<div class="footer">© DenizHosting</div>
<div class="modal" id="loginModal">
  <div class="panel">
    <form method="post">
      <input type="hidden" name="action" value="login">
      <h3 style="margin:0 0 10px 0">Owner Login</h3>
      <?php if(isset($_SESSION['login_error'])){echo '<div style="color:#ef4444;margin-bottom:8px">'.htmlspecialchars($_SESSION['login_error']).'</div>';unset($_SESSION['login_error']);} ?>
      <label>Username</label>
      <input name="username" autocomplete="username" required>
      <label style="margin-top:8px">Password</label>
      <input type="password" name="password" autocomplete="current-password" required>
      <div style="margin-top:12px;display:flex;gap:8px;justify-content:flex-end">
        <button class="btn" type="submit">Sign in</button>
      </div>
    </form>
  </div>
  <script>
    const m=document.getElementById('loginModal');
    const open=()=>m.classList.add('show');
    const close=(e)=>{if(e.target===m)m.classList.remove('show')};
    ['ownerBtn','ownerBtn2','ownerBtn3'].forEach(id=>{const el=document.getElementById(id);if(el)el.onclick=open});
    m.onclick=close;
    document.addEventListener('keydown',e=>{if(e.key==='Escape')m.classList.remove('show')});
  </script>
</div>
</body>
</html>
