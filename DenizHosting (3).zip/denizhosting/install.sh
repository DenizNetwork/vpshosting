#!/usr/bin/env bash
# =============================================================================
# DenizHosting — Install / Uninstall Script
# =============================================================================
set -euo pipefail

RED='\033[0;31m';    GREEN='\033[0;32m';  YELLOW='\033[1;33m'
BLUE='\033[0;34m';   CYAN='\033[0;36m';   BOLD='\033[1m';  NC='\033[0m'

log()     { echo -e "${GREEN}[✓]${NC} $*"; }
info()    { echo -e "${CYAN}[→]${NC} $*"; }
warn()    { echo -e "${YELLOW}[!]${NC} $*"; }
error()   { echo -e "${RED}[✗]${NC} $*"; exit 1; }
section() {
    echo -e "\n${BOLD}${BLUE}══════════════════════════════════════════${NC}"
    echo -e "${BOLD}${BLUE}  $*${NC}"
    echo -e "${BOLD}${BLUE}══════════════════════════════════════════${NC}\n"
}

if [[ $EUID -ne 0 ]]; then
    error "This script must be run as root.  →  sudo bash install.sh"
fi

OS_ID="$(grep -oP '(?<=^ID=).+' /etc/os-release 2>/dev/null | tr -d '"' | tr '[:upper:]' '[:lower:]')"
OS_CODENAME="$(grep -oP '(?<=^VERSION_CODENAME=).+' /etc/os-release 2>/dev/null | tr -d '"')"
[[ -z "$OS_CODENAME" ]] && OS_CODENAME="$(lsb_release -sc 2>/dev/null || echo 'bookworm')"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

WEB_ROOT="/var/www/denizhosting"
SCRIPTS_DIR="/opt/denizhosting/scripts"
IMAGES_DIR="/opt/denizhosting/images"
VMS_DIR="/opt/denizhosting/vms"
LOG_DIR="/var/log/denizhosting"
DB_NAME="denizhosting"
DB_USER="denizhost_user"
OWNER_USERNAME="DenizHost"
OWNER_PASSWORD="Denizmax"

show_banner() {
    clear
    echo -e "${BOLD}${BLUE}"
    echo "  ____             _      _   _           _   _"
    echo " |  _ \  ___ _ __ (_)____|  | | ___  ___ | |_(_)_ __   __ _"
    echo " | | | |/ _ \ '_ \| |_  /   | |/ _ \/ __|| __| | '_ \ / _\` |"
    echo " | |_| |  __/ | | | |/ /    | | (_) \__ \| |_| | | | | (_| |"
    echo " |____/ \___|_| |_|_/___|   |_|\___/|___/ \__|_|_| |_|\__, |"
    echo "                                                         |___/"
    echo -e "${NC}"
    echo -e "  ${CYAN}${BOLD}VPS Hosting Panel — Manager Script${NC}"
    echo -e "  ${CYAN}OS: ${OS_ID} (${OS_CODENAME})${NC}\n"
}

show_banner

echo -e "${BOLD}  What would you like to do?${NC}\n"
echo -e "  ${GREEN}[1]${NC}  Install DenizHosting"
echo -e "  ${RED}[2]${NC}  Uninstall DenizHosting"
echo -e "  ${YELLOW}[3]${NC}  Exit\n"
read -rp "  Enter choice [1/2/3]: " MAIN_CHOICE

# =============================================================================
#  UNINSTALL
# =============================================================================
if [[ "$MAIN_CHOICE" == "2" ]]; then
    show_banner
    echo -e "${RED}${BOLD}  ⚠  UNINSTALL — This will remove DenizHosting completely.${NC}\n"
    echo -e "  Everything below will be permanently DELETED:\n"
    echo -e "   ${RED}•${NC} Nginx vhost + web files   (${WEB_ROOT})"
    echo -e "   ${RED}•${NC} PHP 8.1-FPM"
    echo -e "   ${RED}•${NC} MariaDB database           (${DB_NAME})"
    echo -e "   ${RED}•${NC} QEMU/KVM + Libvirt + all running VMs"
    echo -e "   ${RED}•${NC} Tailscale"
    echo -e "   ${RED}•${NC} Cloudflare Tunnel          (cloudflared service + package)"
    echo -e "   ${RED}•${NC} All scripts, logs, images  (/opt/denizhosting, ${LOG_DIR})\n"
    read -rp "  Type  CONFIRM  to proceed: " CONFIRM_INPUT
    [[ "$CONFIRM_INPUT" != "CONFIRM" ]] && echo "Aborted." && exit 0

    section "Stopping Services"

    info "Stopping Cloudflare Tunnel..."
    systemctl stop    cloudflared 2>/dev/null || true
    systemctl disable cloudflared 2>/dev/null || true
    if command -v cloudflared &>/dev/null; then
        cloudflared service uninstall 2>/dev/null || true
    fi
    apt-get remove --purge -y cloudflared 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/cloudflared.list
    rm -f /etc/apt/trusted.gpg.d/cloudflare.gpg
    rm -rf /etc/cloudflared
    rm -f /usr/local/bin/cloudflared
    log "Cloudflare Tunnel removed"

    info "Stopping Tailscale..."
    systemctl stop    tailscaled 2>/dev/null || true
    systemctl disable tailscaled 2>/dev/null || true
    apt-get remove --purge -y tailscale 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/tailscale.list
    rm -f /etc/apt/trusted.gpg.d/tailscale.gpg
    log "Tailscale removed"

    info "Stopping Nginx, PHP, MariaDB, Libvirt..."
    for svc in nginx php8.1-fpm mariadb libvirtd; do
        systemctl stop    "$svc" 2>/dev/null || true
        systemctl disable "$svc" 2>/dev/null || true
    done

    section "Destroying All VMs"
    if command -v virsh &>/dev/null; then
        mapfile -t VM_LIST < <(virsh list --all --name 2>/dev/null | grep -v '^$' || true)
        if [[ ${#VM_LIST[@]} -gt 0 ]]; then
            for vm in "${VM_LIST[@]}"; do
                info "Destroying: ${vm}"
                virsh destroy  "$vm" 2>/dev/null || true
                virsh undefine "$vm" --remove-all-storage 2>/dev/null || true
            done
            log "All VMs destroyed"
        else
            log "No VMs found"
        fi
    fi

    section "Removing Packages"
    info "Removing Nginx..."
    apt-get remove --purge -y nginx nginx-common nginx-full 2>/dev/null || true
    rm -rf /etc/nginx

    info "Removing PHP 8.1..."
    apt-get remove --purge -y \
        php8.1 php8.1-fpm php8.1-mysql php8.1-curl php8.1-mbstring \
        php8.1-xml php8.1-zip php8.1-intl php8.1-bcmath php8.1-gd 2>/dev/null || true
    rm -f /etc/apt/sources.list.d/sury-php.list
    rm -f /etc/apt/trusted.gpg.d/sury-php.gpg

    info "Removing MariaDB..."
    apt-get remove --purge -y mariadb-server mariadb-client 2>/dev/null || true
    rm -rf /var/lib/mysql /etc/mysql

    info "Removing QEMU/KVM & Libvirt..."
    apt-get remove --purge -y \
        qemu-kvm libvirt-daemon-system libvirt-clients \
        bridge-utils virtinst virt-manager \
        cloud-image-utils cloud-init 2>/dev/null || true
    rm -rf /etc/libvirt

    apt-get autoremove -y 2>/dev/null || true
    apt-get autoclean  -y 2>/dev/null || true

    section "Removing Files"
    rm -rf "${WEB_ROOT}"
    rm -rf /opt/denizhosting
    rm -rf "${LOG_DIR}"
    rm -f  /etc/sudoers.d/denizhosting
    rm -f  /etc/nginx/sites-available/denizhosting 2>/dev/null || true
    rm -f  /etc/nginx/sites-enabled/denizhosting   2>/dev/null || true
    log "All files removed"

    section "Resetting Firewall"
    ufw --force reset > /dev/null 2>&1 || true
    log "UFW reset to defaults"

    echo ""
    echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════════════╗"
    echo -e "║    DenizHosting has been fully uninstalled!      ║"
    echo -e "╚══════════════════════════════════════════════════╝${NC}"
    echo ""
    exit 0
fi

[[ "$MAIN_CHOICE" == "3" ]] && echo "Bye!" && exit 0
[[ "$MAIN_CHOICE" != "1" ]] && error "Invalid choice."

# =============================================================================
#  INSTALL — Interactive Setup Questions
# =============================================================================
show_banner
echo -e "${BOLD}  DenizHosting — Installation Setup${NC}"
echo -e "  Answer 2 questions and the rest runs fully automated.\n"
echo -e "  ${YELLOW}─────────────────────────────────────────────────────${NC}\n"

# ── Question 1: Domain ────────────────────────────────────────────────────────
echo -e "${BOLD}${CYAN}  Step 1 of 2 — Panel Domain${NC}"
echo -e "  Enter the domain your panel will be accessible at."
echo -e "  This domain should point to your Cloudflare Tunnel.\n"
echo -e "  Examples:  vps.yourdomain.com   panel.example.org\n"

while true; do
    read -rp "  → Your panel domain: " PANEL_DOMAIN
    PANEL_DOMAIN="${PANEL_DOMAIN// /}"
    if [[ -z "$PANEL_DOMAIN" ]]; then
        warn "Domain cannot be empty."
    elif [[ ! "$PANEL_DOMAIN" =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)+$ ]]; then
        warn "Doesn't look like a valid domain (e.g. vps.example.com). Try again."
    else
        log "Domain: ${PANEL_DOMAIN}"
        break
    fi
done

echo ""

# ── Question 2: Cloudflare token ──────────────────────────────────────────────
echo -e "${BOLD}${CYAN}  Step 2 of 2 — Cloudflare Tunnel Token${NC}"
echo -e "  How to get your token:"
echo -e "    1. Go to: ${CYAN}https://one.dash.cloudflare.com${NC}"
echo -e "    2. Zero Trust → Networks → Tunnels → Create a Tunnel"
echo -e "    3. Choose ${BOLD}cloudflared${NC}, give it a name, click Save"
echo -e "    4. On the next screen you'll see a command like:"
echo -e "       ${YELLOW}cloudflared service install eyJhIjoiZW...${NC}"
echo -e "    5. Copy ONLY the long token part (after 'service install')\n"
echo -e "  Token example (yours will look like this):"
echo -e "  ${YELLOW}eyJhIjoiZWMwZWZkNWYxMzUzY2NhMTdmMDE4ZjhkOTdiYzEyYmYiLCJ0IjoiZmY1NWM4${NC}\n"

while true; do
    read -rp "  → Paste your Cloudflare Tunnel token: " CF_TOKEN
    CF_TOKEN="${CF_TOKEN// /}"
    if [[ -z "$CF_TOKEN" ]]; then
        warn "Token cannot be empty."
    elif [[ ${#CF_TOKEN} -lt 40 ]]; then
        warn "Token looks too short (${#CF_TOKEN} chars). Make sure you copied the full token."
    else
        log "Token accepted — ${#CF_TOKEN} characters"
        break
    fi
done

echo ""
echo -e "${YELLOW}  ─────────────────────────────────────────────────────${NC}"
echo -e "  ${BOLD}Setup Summary:${NC}"
echo -e "   Panel domain : ${CYAN}${PANEL_DOMAIN}${NC}"
echo -e "   CF Token     : ${CYAN}${CF_TOKEN:0:16}...${CF_TOKEN: -8}${NC}  (${#CF_TOKEN} chars)"
echo -e "${YELLOW}  ─────────────────────────────────────────────────────${NC}\n"
read -rp "  → Looks good? Press ENTER to install, or Ctrl+C to cancel: "

DB_PASS="$(openssl rand -base64 24 | tr -d '+=/' | head -c 28)"
RECEIVER_TOKEN="$(openssl rand -hex 32)"

# =============================================================================
section "Step 1 — System Update & Base Packages"
info "Updating package lists..."
apt-get update -qq

info "Installing base packages..."
BASE_PKGS="curl wget git unzip apt-transport-https ca-certificates gnupg lsb-release ufw openssl jq"
[[ "${OS_ID}" == "ubuntu" ]] && BASE_PKGS="${BASE_PKGS} software-properties-common"
# shellcheck disable=SC2086
apt-get install -y -qq ${BASE_PKGS}
log "Base packages done"

# =============================================================================
section "Step 2 — QEMU/KVM & Libvirt"
apt-get install -y -qq \
    qemu-kvm libvirt-daemon-system libvirt-clients \
    bridge-utils virtinst virt-manager \
    cloud-image-utils cloud-init
systemctl enable --now libvirtd
usermod -aG libvirt www-data 2>/dev/null || true
usermod -aG kvm     www-data 2>/dev/null || true
log "QEMU/KVM + Libvirt ready"

# =============================================================================
section "Step 3 — Nginx"
apt-get install -y -qq nginx
systemctl enable nginx
log "Nginx installed"

# =============================================================================
section "Step 4 — PHP 8.1"
info "Adding PHP 8.1 repository..."
rm -f /etc/apt/sources.list.d/sury-php.list /etc/apt/trusted.gpg.d/sury-php.gpg 2>/dev/null || true

if [[ "${OS_ID}" == "ubuntu" ]]; then
    add-apt-repository -y ppa:ondrej/php
else
    curl -fsSL https://packages.sury.org/php/apt.gpg \
        | gpg --dearmor -o /etc/apt/trusted.gpg.d/sury-php.gpg
    echo "deb https://packages.sury.org/php/ ${OS_CODENAME} main" \
        > /etc/apt/sources.list.d/sury-php.list
fi
apt-get update -qq

apt-get install -y -qq \
    php8.1 php8.1-fpm php8.1-mysql php8.1-curl php8.1-mbstring \
    php8.1-xml php8.1-zip php8.1-intl php8.1-bcmath php8.1-gd
systemctl enable php8.1-fpm
log "PHP 8.1-FPM installed"

# =============================================================================
section "Step 5 — MariaDB"
apt-get install -y -qq mariadb-server mariadb-client
systemctl enable --now mariadb

HASHED_PASS=$(php8.1 -r "echo password_hash('${OWNER_PASSWORD}', PASSWORD_BCRYPT, ['cost'=>12]);")

mysql -uroot << MYSQL_BLOCK
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'127.0.0.1';
USE \`${DB_NAME}\`;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('owner','user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vps_instances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vm_name VARCHAR(100) NOT NULL UNIQUE,
    status ENUM('provisioning','installing','online','offline','error') DEFAULT 'provisioning',
    tailscale_auth_url TEXT,
    tailscale_ip VARCHAR(45),
    cores INT DEFAULT 7,
    ram_mb INT DEFAULT 4000,
    disk_gb INT DEFAULT 1000,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_vps_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO settings (setting_key, setting_value) VALUES
    ('work_mode',                '0'),
    ('panel_name',               'DenizHosting'),
    ('panel_domain',             '${PANEL_DOMAIN}'),
    ('tailscale_receiver_token', '${RECEIVER_TOKEN}')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

INSERT INTO users (username, password, role) VALUES
    ('${OWNER_USERNAME}', '${HASHED_PASS}', 'owner')
ON DUPLICATE KEY UPDATE password = VALUES(password), role = 'owner';

FLUSH PRIVILEGES;
MYSQL_BLOCK
log "MariaDB database '${DB_NAME}' configured"

# =============================================================================
section "Step 6 — Tailscale"
curl -fsSL https://tailscale.com/install.sh | sh \
    || warn "Tailscale install may have failed — install manually if needed"
log "Tailscale installed"

# =============================================================================
section "Step 7 — Cloudflare Tunnel (cloudflared)"
info "Installing cloudflared..."

# Cloudflare's apt repo only publishes packages for stable Debian/Ubuntu releases.
# For Debian trixie/sid or other unsupported codenames, we pin to bookworm.
CF_REPO_CODENAME="${OS_CODENAME}"
if [[ "${OS_ID}" == "debian" ]]; then
    case "${OS_CODENAME}" in
        bookworm|bullseye|buster) : ;;   # supported — use as-is
        *) CF_REPO_CODENAME="bookworm"   # trixie, sid, etc → pin to bookworm
           warn "Debian '${OS_CODENAME}' not in CF repo — using bookworm packages (compatible)"
           ;;
    esac
elif [[ "${OS_ID}" == "ubuntu" ]]; then
    case "${OS_CODENAME}" in
        focal|jammy|noble) : ;;          # supported
        *) CF_REPO_CODENAME="jammy"
           warn "Ubuntu '${OS_CODENAME}' not in CF repo — using jammy packages (compatible)"
           ;;
    esac
fi

install_cloudflared_binary() {
    warn "Falling back to direct binary download from GitHub..."
    ARCH="$(dpkg --print-architecture 2>/dev/null || echo 'amd64')"
    # Map Debian arch names to GitHub release names
    [[ "$ARCH" == "amd64" ]] && GH_ARCH="amd64"
    [[ "$ARCH" == "arm64" ]] && GH_ARCH="arm64"
    [[ "$ARCH" == "armhf" ]] && GH_ARCH="arm"
    GH_ARCH="${GH_ARCH:-amd64}"
    curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${GH_ARCH}" \
        -o /usr/local/bin/cloudflared
    chmod +x /usr/local/bin/cloudflared
}

# Try apt repo first
CF_REPO_OK=false
{
    curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg \
        | gpg --dearmor -o /etc/apt/trusted.gpg.d/cloudflare.gpg

    echo "deb [signed-by=/etc/apt/trusted.gpg.d/cloudflare.gpg] https://pkg.cloudflare.com/cloudflared ${CF_REPO_CODENAME} main" \
        > /etc/apt/sources.list.d/cloudflared.list

    apt-get update -qq 2>/dev/null && CF_REPO_OK=true
} || true

if $CF_REPO_OK; then
    apt-get install -y -qq cloudflared 2>/dev/null && log "cloudflared installed via apt" \
        || install_cloudflared_binary
else
    # Repo failed entirely — go straight to binary
    rm -f /etc/apt/sources.list.d/cloudflared.list /etc/apt/trusted.gpg.d/cloudflare.gpg
    install_cloudflared_binary
fi

CF_VER="$(cloudflared --version 2>/dev/null | head -1 || echo 'unknown')"
log "cloudflared installed: ${CF_VER}"

info "Registering tunnel as a system service..."
cloudflared service install "${CF_TOKEN}"

systemctl enable cloudflared
systemctl start  cloudflared
sleep 3

if systemctl is-active --quiet cloudflared; then
    log "Cloudflare Tunnel is RUNNING"
else
    warn "Tunnel didn't start cleanly. Check: sudo systemctl status cloudflared"
    warn "Re-run manually: sudo cloudflared service install <token>"
fi

# =============================================================================
section "Step 8 — Directory Structure"
mkdir -p "${WEB_ROOT}" "${SCRIPTS_DIR}" "${IMAGES_DIR}" "${VMS_DIR}" "${LOG_DIR}"
log "Directories created"

# =============================================================================
section "Step 9 — Web Files"
cat > "${WEB_ROOT}/config.php" << PHPCONFIG
<?php
define('DB_HOST',         '127.0.0.1');
define('DB_PORT',         '3306');
define('DB_NAME',         '${DB_NAME}');
define('DB_USER',         '${DB_USER}');
define('DB_PASS',         '${DB_PASS}');
define('SCRIPTS_PATH',    '${SCRIPTS_DIR}');
define('RECEIVER_SECRET', '${RECEIVER_TOKEN}');
define('PANEL_URL',       'https://${PANEL_DOMAIN}');
PHPCONFIG

for f in index.php db.php receiver.php; do
    if [[ -f "${SCRIPT_DIR}/web/${f}" ]]; then
        cp "${SCRIPT_DIR}/web/${f}" "${WEB_ROOT}/${f}"
        log "Copied ${f}"
    else
        warn "${f} not found in ${SCRIPT_DIR}/web/ — copy it manually to ${WEB_ROOT}/"
    fi
done
sed -i "s/CHANGE_THIS_SECRET_TOKEN_123/${RECEIVER_TOKEN}/g" \
    "${WEB_ROOT}/receiver.php" 2>/dev/null || true
log "Web files installed"

# =============================================================================
section "Step 10 — Provisioning Script"
if [[ -f "${SCRIPT_DIR}/scripts/create_vps.sh" ]]; then
    cp "${SCRIPT_DIR}/scripts/create_vps.sh" "${SCRIPTS_DIR}/create_vps.sh"
    sed -i "s|https://vps.deniznetwork.qzz.io|https://${PANEL_DOMAIN}|g" \
        "${SCRIPTS_DIR}/create_vps.sh"
    chmod 750 "${SCRIPTS_DIR}/create_vps.sh"
    log "create_vps.sh installed"
else
    warn "create_vps.sh not found — copy it to ${SCRIPTS_DIR}/create_vps.sh manually"
fi

# =============================================================================
section "Step 11 — Permissions & Sudoers"
chown -R www-data:www-data "${WEB_ROOT}"
chmod -R 755 "${WEB_ROOT}"
chmod 640 "${WEB_ROOT}/config.php"
chmod 640 "${WEB_ROOT}/db.php"
chown -R www-data:www-data "${VMS_DIR}" "${LOG_DIR}"
chown -R root:libvirt "${SCRIPTS_DIR}" "${IMAGES_DIR}"
chmod -R 770 "${IMAGES_DIR}" "${VMS_DIR}"

SUDOERS_FILE="/etc/sudoers.d/denizhosting"
echo "www-data ALL=(ALL) NOPASSWD: /usr/bin/bash ${SCRIPTS_DIR}/create_vps.sh *" \
    > "${SUDOERS_FILE}"
chmod 440 "${SUDOERS_FILE}"
visudo -cf "${SUDOERS_FILE}" && log "Sudoers configured" || error "Sudoers syntax error!"

# =============================================================================
section "Step 12 — Nginx Virtual Host"
# With Cloudflare Tunnel, Nginx only needs to listen on localhost — no SSL needed here.
cat > /etc/nginx/sites-available/denizhosting << NGINXEOF
# DenizHosting — Cloudflare Tunnel routes traffic to this local listener
server {
    listen 127.0.0.1:80;
    server_name ${PANEL_DOMAIN};

    root ${WEB_ROOT};
    index index.php;

    access_log /var/log/nginx/denizhosting_access.log;
    error_log  /var/log/nginx/denizhosting_error.log;

    add_header X-Frame-Options       "SAMEORIGIN"  always;
    add_header X-Content-Type-Options "nosniff"    always;

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_hide_header X-Powered-By;
    }

    location ~ ^/(config|db)\.php$ { deny all; return 404; }
    location / { try_files \$uri \$uri/ /index.php?\$query_string; }
    location ~ /\. { deny all; }
}
NGINXEOF

ln -sf /etc/nginx/sites-available/denizhosting /etc/nginx/sites-enabled/denizhosting
rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true
nginx -t && systemctl reload nginx
log "Nginx configured (localhost:80 → Cloudflare Tunnel)"

# =============================================================================
section "Step 13 — Firewall"
ufw --force reset          > /dev/null 2>&1 || true
ufw default deny incoming  > /dev/null
ufw default allow outgoing > /dev/null
ufw allow 22/tcp  comment "SSH"
ufw allow 80/tcp  comment "HTTP (local + CF tunnel)"
ufw allow 443/tcp comment "HTTPS"
echo "y" | ufw enable > /dev/null 2>&1 || true
log "Firewall configured"

# =============================================================================
section "Step 14 — Backup ZIP"
BACKUP_DIR="/root/denizhosting-backup"
BACKUP_ZIP="/root/denizhosting-backup-$(date +%Y%m%d-%H%M%S).zip"
mkdir -p "${BACKUP_DIR}"
cp -r "${WEB_ROOT}"    "${BACKUP_DIR}/web"     2>/dev/null || true
cp -r "${SCRIPTS_DIR}" "${BACKUP_DIR}/scripts" 2>/dev/null || true

cat > "${BACKUP_DIR}/MANIFEST.txt" << MANIFEST
DenizHosting Install Manifest
Generated  : $(date)
Domain     : ${PANEL_DOMAIN}
DB Name    : ${DB_NAME}
DB User    : ${DB_USER}
DB Pass    : ${DB_PASS}
API Token  : ${RECEIVER_TOKEN}
CF Token   : ${CF_TOKEN}
MANIFEST

apt-get install -y -qq zip > /dev/null 2>&1
zip -r "${BACKUP_ZIP}" "${BACKUP_DIR}" > /dev/null
log "Backup saved: ${BACKUP_ZIP}"

# =============================================================================
echo ""
echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════════════════════╗"
echo -e "║        DenizHosting Installed Successfully!              ║"
echo -e "╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BOLD}🌐  Panel URL       :${NC} ${CYAN}https://${PANEL_DOMAIN}${NC}"
echo -e "${BOLD}👤  Owner Username  :${NC} ${CYAN}${OWNER_USERNAME}${NC}"
echo -e "${BOLD}🔑  Owner Password  :${NC} ${CYAN}${OWNER_PASSWORD}${NC}"
echo ""
echo -e "${BOLD}🗄   Database${NC}"
echo -e "    Name     : ${CYAN}${DB_NAME}${NC}"
echo -e "    User     : ${CYAN}${DB_USER}${NC}"
echo -e "    Password : ${CYAN}${DB_PASS}${NC}"
echo ""
echo -e "${BOLD}🔐  API Token       :${NC} ${CYAN}${RECEIVER_TOKEN}${NC}"
echo ""
echo -e "${BOLD}☁   Cloudflare Tunnel:"
if systemctl is-active --quiet cloudflared 2>/dev/null; then
    echo -e "    ${GREEN}● Running${NC}"
else
    echo -e "    ${RED}● Not running — check: sudo systemctl status cloudflared${NC}"
fi
echo ""
echo -e "${BOLD}${YELLOW}⚠  Final Steps:${NC}"
echo -e "   1. In Cloudflare Zero Trust → Tunnels → your tunnel → Public Hostname:"
echo -e "      Add:  ${CYAN}${PANEL_DOMAIN}${NC}  →  ${CYAN}http://127.0.0.1:80${NC}"
echo -e "   2. Run Tailscale on host: ${CYAN}sudo tailscale up${NC}"
echo -e "   3. Check KVM support:     ${CYAN}kvm-ok${NC}"
echo -e "   4. Credentials backed up: ${CYAN}${BACKUP_ZIP}${NC}"
echo ""
